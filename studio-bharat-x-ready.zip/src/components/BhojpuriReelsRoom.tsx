import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  ChevronDown,
  Clock,
  Copy,
  ExternalLink,
  FolderOpen,
  Image as ImageIcon,
  KeyRound,
  Loader2,
  Lock,
  Maximize2,
  Minimize2,
  Palette,
  Search,
  Sparkles,
  Square,
  Upload,
  Users,
  Volume2,
  X,
} from 'lucide-react';
import { DEPARTMENT_META, UI_COPY } from '../i18n/translations';
import {
  compressCharacterPhoto,
  extractCharacterDnaWithGeminiVision,
  formatGoogleFlowPrompt,
  generateBhojpuriArtwork,
  GOOGLE_FLOW_URL,
  loadBhojpuriSchedule,
  loadCharacterVault,
  loadSavedBhojpuriStory,
  markBhojpuriStoryRead,
  runBhojpuriResearchAndStoryPipeline,
  saveBhojpuriSchedule,
  saveBhojpuriStory,
  saveCharacterVault,
  syncBhojpuriStoryToProject,
} from '../services/bhojpuriReelsService';
import {
  speakWithStudioVoice,
  stopStudioSpeech,
  VOICE_PERSONAS,
} from '../services/cloudTtsService';
import { BhojpuriVideoEditor } from './BhojpuriVideoEditor';
import {
  BhojpuriCharacterSlot,
  BhojpuriPipelineStepId,
  BhojpuriPipelineStepStatus,
  BhojpuriScene,
  BhojpuriScheduleFrequency,
  BhojpuriScheduleState,
  BhojpuriStoryPlan,
  BhojpuriVedaCommandAction,
  DepartmentId,
  DepartmentPreviewState,
  Language,
  PreviewMode,
  StudioProject,
  VoicePersona,
} from '../types/studio';

interface BhojpuriReelsRoomProps {
  language: Language;
  project: StudioProject | null;
  previewState: DepartmentPreviewState;
  hasNewStoryBadge: boolean;
  onClearNewStoryBadge: () => void;
  hasNewReelBadge?: boolean;
  onClearNewReelBadge?: () => void;
  pendingBhojpuriCommand?: { action: BhojpuriVedaCommandAction; topic?: string } | null;
  onConsumeBhojpuriCommand?: () => void;
  onUpdatePreviewState: (
    department: DepartmentId,
    updater: (prev: DepartmentPreviewState) => DepartmentPreviewState
  ) => void;
  onProjectSaved: (project: StudioProject) => void;
  onOpenProjects: (filter: DepartmentId) => void;
  onOpenSecrets: () => void;
}

type PipelineStateMap = Record<
  BhojpuriPipelineStepId,
  { status: BhojpuriPipelineStepStatus; detail?: string }
>;

function createIdlePipelineState(): PipelineStateMap {
  return {
    trending: { status: 'idle' },
    desi_context: { status: 'idle' },
    comedy_twist: { status: 'idle' },
    scene_plan: { status: 'idle' },
  };
}

function copyTextReliably(text: string): boolean {
  try {
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      void navigator.clipboard.writeText(text).catch(() => {
        // Fallback below if permissions block async clipboard
      });
      return true;
    }
  } catch {
    // Fallback below
  }
  try {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(textarea);
    return ok;
  } catch {
    return false;
  }
}

export const BhojpuriReelsRoom: React.FC<BhojpuriReelsRoomProps> = ({
  language,
  project,
  previewState,
  hasNewStoryBadge,
  onClearNewStoryBadge,
  hasNewReelBadge = false,
  onClearNewReelBadge,
  pendingBhojpuriCommand = null,
  onConsumeBhojpuriCommand,
  onUpdatePreviewState,
  onProjectSaved,
  onOpenProjects,
  onOpenSecrets,
}) => {
  const t = UI_COPY[language];
  const meta = DEPARTMENT_META.bhojpuri;

  const [activeSubTab, setActiveSubTab] = useState<'story' | 'editor'>('story');
  const [editorPendingCmd, setEditorPendingCmd] =
    useState<BhojpuriVedaCommandAction | null>(null);

  const [characters, setCharacters] = useState<BhojpuriCharacterSlot[]>(() =>
    loadCharacterVault()
  );
  const [story, setStory] = useState<BhojpuriStoryPlan | null>(() => loadSavedBhojpuriStory());
  const [schedule, setSchedule] = useState<BhojpuriScheduleState>(() =>
    loadBhojpuriSchedule()
  );

  const [topicInput, setTopicInput] = useState('');
  const [isRunningPipeline, setIsRunningPipeline] = useState(false);
  const [pipelineState, setPipelineState] = useState<PipelineStateMap>(() =>
    createIdlePipelineState()
  );
  const [statusError, setStatusError] = useState<string | null>(null);
  const [needsSecretsHint, setNeedsSecretsHint] = useState(false);

  const [showCharVault, setShowCharVault] = useState(false);
  const [extractingSlot, setExtractingSlot] = useState<number | null>(null);
  const [charNotice, setCharNotice] = useState<string | null>(null);

  // Preview selection: 'thumbnail' or sceneNumber
  const [selectedStageFrame, setSelectedStageFrame] = useState<'thumbnail' | number>('thumbnail');

  // Artwork rendering state
  const [isRenderingAllArt, setIsRenderingAllArt] = useState(false);
  const [artProgressText, setArtProgressText] = useState<string | null>(null);
  const [renderingSingleTarget, setRenderingSingleTarget] = useState<string | null>(null);
  const renderCancelRef = useRef(false);

  // Dialogue TTS preview state
  const [isPlayingDialogues, setIsPlayingDialogues] = useState(false);
  const [activeSpeakingScene, setActiveSpeakingScene] = useState<number | null>(null);
  const dialogueAbortRef = useRef(false);

  // Google Flow & Copy Toast
  const [flowCopiedToast, setFlowCopiedToast] = useState(false);
  const [copiedMetaToast, setCopiedMetaToast] = useState(false);

  // Sync story if auto-scheduler generated a fresh story while user was in another room
  useEffect(() => {
    const latest = loadSavedBhojpuriStory();
    if (latest && latest.id !== story?.id) {
      setStory(latest);
      setSelectedStageFrame('thumbnail');
    }
    setSchedule(loadBhojpuriSchedule());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasNewStoryBadge]);

  // Stop active audio & artwork loops cleanly on unmount
  useEffect(() => {
    return () => {
      dialogueAbortRef.current = true;
      renderCancelRef.current = true;
      stopStudioSpeech();
    };
  }, []);

  const enabledChars = useMemo(
    () => characters.filter((c) => c.enabled),
    [characters]
  );

  const setPreviewMode = (mode: PreviewMode) => {
    onUpdatePreviewState('bhojpuri', (prev) => ({ ...prev, mode }));
  };

  const handleDismissNewStoryBadge = () => {
    const next = markBhojpuriStoryRead();
    setSchedule(next);
    onClearNewStoryBadge();
    setSelectedStageFrame('thumbnail');
    if (previewState.mode === 'folded') {
      setPreviewMode('expanded');
    }
  };

  const handleScheduleChange = (freq: BhojpuriScheduleFrequency) => {
    const next = saveBhojpuriSchedule({
      ...schedule,
      frequency: freq,
    });
    setSchedule(next);
  };

  const updateCharacterSlot = useCallback(
    (slotNumber: 1 | 2 | 3 | 4, updater: (slot: BhojpuriCharacterSlot) => BhojpuriCharacterSlot) => {
      setCharacters((prev) => {
        const next = prev.map((c) => (c.slot === slotNumber ? updater(c) : c));
        saveCharacterVault(next);
        return next;
      });
    },
    []
  );

  const handleToggleCharacterEnabled = (slotNumber: 1 | 2 | 3 | 4) => {
    const target = characters.find((c) => c.slot === slotNumber);
    if (!target) return;
    // Keep at least 2 characters enabled for Bhojpuri comedy banter
    if (target.enabled && enabledChars.length <= 2) {
      setCharNotice(
        language === 'hi'
          ? 'कॉमेडी संवाद के लिए कम से कम 2 कैरेक्टर चालू रखें।'
          : 'Keep at least 2 characters enabled for comedy banter.'
      );
      window.setTimeout(() => setCharNotice(null), 2600);
      return;
    }
    updateCharacterSlot(slotNumber, (c) => ({
      ...c,
      enabled: !c.enabled,
      updatedAt: Date.now(),
    }));
  };

  const handlePhotoUpload = async (slotNumber: 1 | 2 | 3 | 4, file: File | null) => {
    if (!file) return;
    const slotObj = characters.find((c) => c.slot === slotNumber);
    if (!slotObj) return;

    setExtractingSlot(slotNumber);
    setCharNotice(null);
    setNeedsSecretsHint(false);

    try {
      const compressedDataUrl = await compressCharacterPhoto(file);
      updateCharacterSlot(slotNumber, (c) => ({
        ...c,
        photoDataUrl: compressedDataUrl,
        updatedAt: Date.now(),
      }));

      const visionRes = await extractCharacterDnaWithGeminiVision(
        compressedDataUrl,
        slotObj.name
      );
      if (visionRes.ok && visionRes.dna) {
        updateCharacterSlot(slotNumber, (c) => ({
          ...c,
          dnaDescription: visionRes.dna!,
          dnaLocked: true,
          dnaSource: 'vision',
          updatedAt: Date.now(),
        }));
        setCharNotice(
          `✅ ${slotObj.name} DNA Locked via Gemini Vision (Key ${visionRes.keySlot ?? 1})`
        );
      } else {
        setCharNotice(
          visionRes.error ||
            'Photo saved locally. Add a Gemini key in Secrets to auto-extract Vision DNA.'
        );
        if (visionRes.noKeysConfigured) {
          setNeedsSecretsHint(true);
        }
      }
    } catch {
      setCharNotice('Could not process the selected image file.');
    } finally {
      setExtractingSlot(null);
    }
  };

  const handleRunResearchPipeline = useCallback(
    async (e?: React.FormEvent, overrideTopic?: string) => {
      e?.preventDefault();
      if (isRunningPipeline) return;

      const resolvedTopic = (overrideTopic ?? topicInput).trim();
      setIsRunningPipeline(true);
      setStatusError(null);
      setNeedsSecretsHint(false);
      setPipelineState(createIdlePipelineState());

      try {
        const res = await runBhojpuriResearchAndStoryPipeline({
          customTopic: resolvedTopic || undefined,
          characters,
          language,
          onStepUpdate: (step, status, detail) => {
            setPipelineState((prev) => ({
              ...prev,
              [step]: { status, detail },
            }));
          },
        });

        if (!res.ok || !res.story) {
          setStatusError(res.error || 'Story generation failed.');
          setNeedsSecretsHint(Boolean(res.noKeysConfigured));
          return;
        }

        setStory(res.story);
        setSelectedStageFrame('thumbnail');
        setSchedule(loadBhojpuriSchedule());

        if (previewState.mode === 'folded') {
          onUpdatePreviewState('bhojpuri', (prev) => ({ ...prev, mode: 'expanded' }));
        }

        // Persist structured story + characters + Google Flow prompt into IndexedDB project
        const savedProj = await syncBhojpuriStoryToProject(project, res.story, characters);
        onProjectSaved(savedProj);
        onUpdatePreviewState('bhojpuri', (prev) => ({
          ...prev,
          revision: prev.revision + 1,
        }));
      } finally {
        setIsRunningPipeline(false);
      }
    },
    [
      isRunningPipeline,
      topicInput,
      characters,
      language,
      previewState.mode,
      project,
      onProjectSaved,
      onUpdatePreviewState,
    ]
  );

  // Execute VEDA voice/text commands cleanly (Research, Cloud Render, Facebook Publish)
  useEffect(() => {
    if (!pendingBhojpuriCommand) return;
    if (pendingBhojpuriCommand.action === 'research') {
      setActiveSubTab('story');
      if (pendingBhojpuriCommand.topic) {
        setTopicInput(pendingBhojpuriCommand.topic);
      }
      const topic = pendingBhojpuriCommand.topic;
      onConsumeBhojpuriCommand?.();
      void handleRunResearchPipeline(undefined, topic);
    } else {
      setActiveSubTab('editor');
      setEditorPendingCmd(pendingBhojpuriCommand.action);
      onConsumeBhojpuriCommand?.();
    }
  }, [pendingBhojpuriCommand, onConsumeBhojpuriCommand, handleRunResearchPipeline]);

  const handleGenerateSingleArt = async (target: 'thumbnail' | BhojpuriScene) => {
    if (!story || isRenderingAllArt || renderingSingleTarget) return;
    const key = target === 'thumbnail' ? 'thumbnail' : `scene_${target.sceneNumber}`;
    setRenderingSingleTarget(key);
    setStatusError(null);
    setNeedsSecretsHint(false);

    try {
      const prompt = target === 'thumbnail' ? story.thumbnailPrompt : target.visualPrompt;
      const res = await generateBhojpuriArtwork(prompt, '9:16');
      if (!res.ok || !res.imageUrl) {
        setStatusError(res.error || 'Could not generate 3D artwork.');
        setNeedsSecretsHint(Boolean(res.noKeysConfigured));
        return;
      }

      setStory((prev) => {
        if (!prev) return prev;
        const next: BhojpuriStoryPlan =
          target === 'thumbnail'
            ? { ...prev, thumbnailImageUrl: res.imageUrl }
            : {
                ...prev,
                scenes: prev.scenes.map((s) =>
                  s.sceneNumber === target.sceneNumber ? { ...s, imageUrl: res.imageUrl } : s
                ),
              };
        saveBhojpuriStory(next);
        return next;
      });
      setSelectedStageFrame(target === 'thumbnail' ? 'thumbnail' : target.sceneNumber);
    } finally {
      setRenderingSingleTarget(null);
    }
  };

  const handleGenerateAll3DArt = async () => {
    if (!story) return;
    if (isRenderingAllArt) {
      renderCancelRef.current = true;
      return;
    }

    renderCancelRef.current = false;
    setIsRenderingAllArt(true);
    setStatusError(null);
    setNeedsSecretsHint(false);

    const totalTasks = 1 + story.scenes.length;
    let completed = 0;
    let workingStory: BhojpuriStoryPlan = { ...story, scenes: [...story.scenes] };

    try {
      // 1. Thumbnail first
      setArtProgressText(`1/${totalTasks} · Rendering 9:16 Thumbnail...`);
      const thumbRes = await generateBhojpuriArtwork(workingStory.thumbnailPrompt, '9:16');
      if (!thumbRes.ok) {
        setStatusError(thumbRes.error || 'Artwork generation failed.');
        setNeedsSecretsHint(Boolean(thumbRes.noKeysConfigured));
        return;
      }
      if (thumbRes.imageUrl) {
        completed += 1;
        workingStory = { ...workingStory, thumbnailImageUrl: thumbRes.imageUrl };
        setStory(workingStory);
        saveBhojpuriStory(workingStory);
        setSelectedStageFrame('thumbnail');
      }

      // 2. Render each scene sequentially with failover
      for (let i = 0; i < workingStory.scenes.length; i++) {
        if (renderCancelRef.current) break;
        const scene = workingStory.scenes[i];
        setArtProgressText(
          `${i + 2}/${totalTasks} · Scene ${scene.sceneNumber} (${scene.speaker})...`
        );
        const sceneRes = await generateBhojpuriArtwork(scene.visualPrompt, '9:16');
        if (sceneRes.ok && sceneRes.imageUrl) {
          completed += 1;
          workingStory = {
            ...workingStory,
            scenes: workingStory.scenes.map((s) =>
              s.sceneNumber === scene.sceneNumber ? { ...s, imageUrl: sceneRes.imageUrl } : s
            ),
          };
          setStory(workingStory);
          saveBhojpuriStory(workingStory);
        } else if (sceneRes.noKeysConfigured) {
          setStatusError(sceneRes.error || 'No image keys configured.');
          setNeedsSecretsHint(true);
          break;
        }
      }

      setArtProgressText(
        completed > 0 ? `Rendered ${completed}/${totalTasks} watermark-free 3D frames` : null
      );
      window.setTimeout(() => setArtProgressText(null), 4000);
    } finally {
      setIsRenderingAllArt(false);
    }
  };

  const handleStopDialogues = () => {
    dialogueAbortRef.current = true;
    stopStudioSpeech();
    setIsPlayingDialogues(false);
    setActiveSpeakingScene(null);
  };

  const handleListenAllDialogues = async () => {
    if (!story || story.scenes.length === 0) return;
    if (isPlayingDialogues) {
      handleStopDialogues();
      return;
    }

    dialogueAbortRef.current = false;
    setIsPlayingDialogues(true);

    try {
      for (const scene of story.scenes) {
        if (dialogueAbortRef.current) break;
        setActiveSpeakingScene(scene.sceneNumber);
        setSelectedStageFrame(scene.sceneNumber);

        const result = await speakWithStudioVoice(scene.dialogue, {
          persona: scene.voicePersona,
          speed: 1.0,
          language,
          messageId: `bhojpuri_scene_${scene.sceneNumber}`,
        });

        if (result === 'cancelled' || result === 'none' || dialogueAbortRef.current) {
          break;
        }
      }
    } finally {
      setIsPlayingDialogues(false);
      setActiveSpeakingScene(null);
    }
  };

  const handleListenSingleScene = async (scene: BhojpuriScene) => {
    if (activeSpeakingScene === scene.sceneNumber) {
      handleStopDialogues();
      return;
    }
    dialogueAbortRef.current = false;
    setIsPlayingDialogues(true);
    setActiveSpeakingScene(scene.sceneNumber);
    setSelectedStageFrame(scene.sceneNumber);

    try {
      await speakWithStudioVoice(scene.dialogue, {
        persona: scene.voicePersona,
        speed: 1.0,
        language,
        messageId: `bhojpuri_scene_${scene.sceneNumber}`,
      });
    } finally {
      setIsPlayingDialogues(false);
      setActiveSpeakingScene(null);
    }
  };

  const googleFlowPromptText = useMemo(() => {
    if (!story) {
      const enabledLines = enabledChars
        .map((c) => `• ${c.name} (${c.voicePersona}): ${c.dnaDescription}`)
        .join('\n');
      return `=== STUDIO BHARAT X — GOOGLE FLOW 9:16 CHARACTER LOCK ===\n${enabledLines}\nStyle: 3D Pixar-style Bhojpuri animated comedy, 9:16 vertical, watermark-free.`;
    }
    return formatGoogleFlowPrompt(story, characters);
  }, [story, characters, enabledChars]);

  const handleCopyForGoogleFlow = () => {
    copyTextReliably(googleFlowPromptText);
    setFlowCopiedToast(true);
    window.setTimeout(() => setFlowCopiedToast(false), 2600);
  };

  const handleCopyTitleAndTags = () => {
    if (!story) return;
    copyTextReliably(`${story.viralTitle}\n\n${story.hashtags.join(' ')}`);
    setCopiedMetaToast(true);
    window.setTimeout(() => setCopiedMetaToast(false), 2000);
  };

  const activeSceneObj = useMemo(() => {
    if (!story || selectedStageFrame === 'thumbnail') return null;
    return story.scenes.find((s) => s.sceneNumber === selectedStageFrame) ?? story.scenes[0] ?? null;
  }, [story, selectedStageFrame]);

  const activeStageImage =
    selectedStageFrame === 'thumbnail'
      ? story?.thumbnailImageUrl
      : activeSceneObj?.imageUrl;

  const pipelineSteps: Array<{ id: BhojpuriPipelineStepId; label: string }> = [
    { id: 'trending', label: t.bhojpuriPipeline1 },
    { id: 'desi_context', label: t.bhojpuriPipeline2 },
    { id: 'comedy_twist', label: t.bhojpuriPipeline3 },
    { id: 'scene_plan', label: t.bhojpuriPipeline4 },
  ];

  return (
    <div
      data-isolated-room="bhojpuri"
      className="h-full flex flex-col min-h-0 overflow-hidden"
    >
      <div className="flex-1 min-h-0 overflow-y-auto studio-scroll">
        <div className="w-full max-w-6xl mx-auto px-3 sm:px-6 py-3.5 sm:py-5 space-y-3.5">
          {/* Room Header Strip + Corner New Story Ready Badge */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="min-w-0 flex items-center gap-2 flex-wrap">
              <h1
                className="text-base sm:text-lg font-semibold text-[#F4F5F7] truncate"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {meta.cardTitle[language]}
              </h1>
              <span className="text-xs text-[#6F7686] shrink-0" aria-hidden="true">
                ·
              </span>
              <span className="text-xs text-[#9BA1AE] truncate">
                {project ? project.name : meta.stageFormatLabel[language]}
              </span>

              {(hasNewStoryBadge || schedule.hasUnreadStory) && story && (
                <button
                  type="button"
                  onClick={() => {
                    setActiveSubTab('story');
                    handleDismissNewStoryBadge();
                  }}
                  className="h-7 px-2.5 rounded-full bg-amber-500/20 border border-amber-400/50 text-amber-200 text-[11px] font-semibold hover:bg-amber-500/30 transition-colors inline-flex items-center gap-1 whitespace-nowrap animate-pulse"
                >
                  <span>{t.bhojpuriNewStoryReady}</span>
                </button>
              )}

              {hasNewReelBadge && (
                <button
                  type="button"
                  onClick={() => {
                    setActiveSubTab('editor');
                    onClearNewReelBadge?.();
                    if (previewState.mode === 'folded') setPreviewMode('expanded');
                  }}
                  className="h-7 px-2.5 rounded-full bg-sky-500/20 border border-sky-400/50 text-sky-200 text-[11px] font-semibold hover:bg-sky-500/30 transition-colors inline-flex items-center gap-1 whitespace-nowrap animate-pulse"
                >
                  <span>{t.bhojpuriNewReelReady}</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-1.5 flex-wrap shrink-0">
              {/* Auto-Schedule Selector (Off / 6h / Daily) */}
              <div
                className="flex items-center gap-0.5 p-0.5 rounded-xl bg-[#12151E] border border-white/10"
                role="group"
                aria-label={t.bhojpuriAutoSchedule}
              >
                <Clock className="w-3 h-3 text-amber-400 ml-1.5 mr-0.5 shrink-0" />
                {(['off', '6h', 'daily'] as BhojpuriScheduleFrequency[]).map((freq) => {
                  const active = schedule.frequency === freq;
                  const label =
                    freq === 'off'
                      ? t.bhojpuriScheduleOff
                      : freq === '6h'
                        ? t.bhojpuriSchedule6h
                        : t.bhojpuriScheduleDaily;
                  return (
                    <button
                      key={freq}
                      type="button"
                      onClick={() => handleScheduleChange(freq)}
                      aria-pressed={active}
                      className={`h-7 px-2 rounded-lg text-[10px] sm:text-[11px] font-medium transition-colors whitespace-nowrap ${
                        active
                          ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                          : 'text-[#9BA1AE] hover:text-white'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>

              {/* 4-Character Vault Toggle */}
              <button
                type="button"
                onClick={() => {
                  setActiveSubTab('story');
                  setShowCharVault((v) => !v);
                }}
                className={`h-8 px-2.5 rounded-xl border text-xs font-medium transition-colors inline-flex items-center gap-1.5 whitespace-nowrap ${
                  showCharVault && activeSubTab === 'story'
                    ? 'bg-amber-500/18 border-amber-400/45 text-amber-200'
                    : 'bg-white/6 border-white/10 text-[#E5E8F0] hover:bg-white/10'
                }`}
              >
                <Users className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="hidden sm:inline">{t.bhojpuriCharVault}</span>
                <span className="font-mono text-[10px] text-amber-300 tabular-nums">
                  ({enabledChars.length}/4)
                </span>
              </button>

              <button
                type="button"
                onClick={() => onOpenProjects('bhojpuri')}
                className="h-8 px-2.5 rounded-xl bg-white/6 border border-white/10 text-xs font-medium text-[#E5E8F0] hover:bg-white/10 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">{t.browseProjects}</span>
              </button>
            </div>
          </div>

          {/* Part 5 / Part 6 Sub-Tab Switcher + Isolated Expand/Compact/Fold Bar */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div
              className="flex items-center gap-1 p-1 rounded-xl bg-[#12151E] border border-white/10"
              role="tablist"
              aria-label="Bhojpuri Reels workflow tabs"
            >
              <button
                type="button"
                role="tab"
                aria-selected={activeSubTab === 'story'}
                onClick={() => setActiveSubTab('story')}
                className={`h-8 px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  activeSubTab === 'story'
                    ? 'bg-amber-500 text-[#0A0B0E]'
                    : 'text-[#9BA1AE] hover:text-white'
                }`}
              >
                {t.bhojpuriTabStory}
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={activeSubTab === 'editor'}
                onClick={() => {
                  setActiveSubTab('editor');
                  if (hasNewReelBadge) onClearNewReelBadge?.();
                }}
                className={`h-8 px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap inline-flex items-center gap-1.5 ${
                  activeSubTab === 'editor'
                    ? 'bg-amber-500 text-[#0A0B0E]'
                    : 'text-[#9BA1AE] hover:text-white'
                }`}
              >
                <span>{t.bhojpuriTabEditor}</span>
                {hasNewReelBadge && activeSubTab !== 'editor' && (
                  <span className="w-2 h-2 rounded-full bg-sky-400" />
                )}
              </button>
            </div>

            {activeSubTab === 'editor' && (
              <div
                className="flex items-center gap-0.5 p-0.5 rounded-lg bg-[#12151E] border border-white/10 shrink-0"
                role="group"
                aria-label="Video editor preview mode"
              >
                <button
                  type="button"
                  onClick={() => setPreviewMode('expanded')}
                  aria-pressed={previewState.mode === 'expanded'}
                  className={`h-7 px-2 rounded-md text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                    previewState.mode === 'expanded'
                      ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                      : 'text-[#9BA1AE] hover:text-white'
                  }`}
                >
                  <Maximize2 className="w-3 h-3" />
                  <span className="hidden sm:inline">{t.expand}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewMode('compact')}
                  aria-pressed={previewState.mode === 'compact'}
                  className={`h-7 px-2 rounded-md text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                    previewState.mode === 'compact'
                      ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                      : 'text-[#9BA1AE] hover:text-white'
                  }`}
                >
                  <Minimize2 className="w-3 h-3" />
                  <span className="hidden sm:inline">{t.compact}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewMode('folded')}
                  aria-pressed={previewState.mode === 'folded'}
                  className={`h-7 px-2 rounded-md text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                    previewState.mode === 'folded'
                      ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                      : 'text-[#9BA1AE] hover:text-white'
                  }`}
                >
                  <ChevronDown
                    className={`w-3 h-3 transition-transform ${
                      previewState.mode === 'folded' ? '-rotate-90' : ''
                    }`}
                  />
                  <span className="hidden sm:inline">{t.fold}</span>
                </button>
              </div>
            )}
          </div>

          {activeSubTab === 'editor' ? (
            <BhojpuriVideoEditor
              language={language}
              story={story}
              characters={characters}
              previewMode={previewState.mode}
              pendingCommand={editorPendingCmd}
              onConsumeCommand={() => setEditorPendingCmd(null)}
              onOpenSecrets={onOpenSecrets}
            />
          ) : (
            <>
          {/* Dedicated Isolated Foldable 9:16 Reel Preview Stage */}
          <section
            aria-label={`${meta.stageTitle[language]} (${previewState.mode})`}
            className="rounded-2xl studio-surface overflow-hidden"
          >
            {/* Preview Control Bar */}
            <div className="px-3 py-2 border-b border-white/8 bg-[#151821] flex items-center justify-between gap-2 flex-wrap">
              <div className="min-w-0 flex items-center gap-2">
                <span className={`text-xs font-semibold truncate ${meta.accentClass}`}>
                  {meta.stageTitle[language]}
                </span>
                {story && (
                  <span className="font-mono text-[10px] text-[#9BA1AE] tabular-nums whitespace-nowrap">
                    {story.scenes.length} scenes · {story.totalDurationSec}s
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 flex-wrap shrink-0">
                {/* Prominent Google Flow Bridge (real anchor, zero window.open) */}
                <a
                  href={GOOGLE_FLOW_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={handleCopyForGoogleFlow}
                  className="h-7 px-2.5 rounded-lg bg-amber-500 text-[#0A0B0E] text-[11px] font-semibold hover:bg-amber-400 transition-colors inline-flex items-center gap-1 whitespace-nowrap"
                >
                  <span>{flowCopiedToast ? t.bhojpuriCopiedToast : t.bhojpuriOpenGoogleFlow}</span>
                  <ExternalLink className="w-3 h-3 shrink-0" />
                </a>

                {/* Isolated Expand / Compact / Fold Segmented Control */}
                <div
                  className="flex items-center gap-0.5 p-0.5 rounded-lg bg-[#0A0B0E] border border-white/8 shrink-0"
                  role="group"
                  aria-label="Preview stage layout mode"
                >
                  <button
                    type="button"
                    onClick={() => setPreviewMode('expanded')}
                    aria-pressed={previewState.mode === 'expanded'}
                    className={`h-7 px-2 rounded-md text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                      previewState.mode === 'expanded'
                        ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                        : 'text-[#9BA1AE] hover:text-white'
                    }`}
                  >
                    <Maximize2 className="w-3 h-3" />
                    <span className="hidden sm:inline">{t.expand}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewMode('compact')}
                    aria-pressed={previewState.mode === 'compact'}
                    className={`h-7 px-2 rounded-md text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                      previewState.mode === 'compact'
                        ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                        : 'text-[#9BA1AE] hover:text-white'
                    }`}
                  >
                    <Minimize2 className="w-3 h-3" />
                    <span className="hidden sm:inline">{t.compact}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewMode('folded')}
                    aria-pressed={previewState.mode === 'folded'}
                    className={`h-7 px-2 rounded-md text-[11px] font-medium transition-colors inline-flex items-center gap-1 whitespace-nowrap ${
                      previewState.mode === 'folded'
                        ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                        : 'text-[#9BA1AE] hover:text-white'
                    }`}
                  >
                    <ChevronDown
                      className={`w-3 h-3 transition-transform ${
                        previewState.mode === 'folded' ? '-rotate-90' : ''
                      }`}
                    />
                    <span className="hidden sm:inline">{t.fold}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Preview Body */}
            {previewState.mode !== 'folded' && (
              <div className="p-3.5 sm:p-4 bg-[#0C0E13]">
                {!story ? (
                  <div className="py-6 px-3 text-center space-y-2 max-w-md mx-auto">
                    <div className="text-xs font-semibold text-rose-300">
                      9:16 Bhojpuri Comedy Reel Stage Ready
                    </div>
                    <p className="text-[11px] text-[#8D94A3] leading-relaxed">
                      Tap <span className="text-amber-300 font-medium">{t.bhojpuriResearchBtn}</span>{' '}
                      below to run live trend research, write a 30s–60s Motu-Patlu style Bhojpuri
                      comedy script with your locked characters, render watermark-free 3D art, and
                      launch Google Flow.
                    </p>
                  </div>
                ) : (
                  <div
                    className={`flex flex-col ${
                      previewState.mode === 'expanded' ? 'sm:flex-row' : 'sm:flex-row'
                    } gap-3.5 items-center sm:items-stretch`}
                  >
                    {/* 9:16 Vertical Reel Frame */}
                    <div
                      className={`relative rounded-xl border border-white/12 bg-[#12151E] overflow-hidden shrink-0 flex flex-col justify-between ${
                        previewState.mode === 'expanded'
                          ? 'w-[196px] h-[332px]'
                          : 'w-[120px] h-[184px]'
                      }`}
                    >
                      {activeStageImage ? (
                        <img
                          src={activeStageImage}
                          alt={
                            selectedStageFrame === 'thumbnail'
                              ? story.viralTitle
                              : `Scene ${activeSceneObj?.sceneNumber}`
                          }
                          className="absolute inset-0 w-full h-full object-cover"
                        />
                      ) : (
                        <div className="absolute inset-0 bg-gradient-to-b from-[#1A1D29] via-[#11141C] to-[#0A0B0E] flex flex-col items-center justify-center p-3 text-center gap-1.5">
                          <ImageIcon className="w-6 h-6 text-amber-400/60" />
                          <span className="text-[10px] text-[#9BA1AE] leading-snug">
                            {selectedStageFrame === 'thumbnail'
                              ? t.bhojpuriThumbnailLabel
                              : `Scene ${activeSceneObj?.sceneNumber} 3D Preview`}
                          </span>
                        </div>
                      )}

                      {/* Top Overlay Chip */}
                      <div className="relative z-10 p-2 flex items-center justify-between gap-1 bg-gradient-to-b from-black/75 to-transparent">
                        <span className="px-1.5 py-0.5 rounded bg-black/65 border border-white/15 text-[9px] font-semibold text-amber-300 uppercase tracking-wide">
                          {selectedStageFrame === 'thumbnail'
                            ? '9:16 Thumb'
                            : `S${activeSceneObj?.sceneNumber} · ${activeSceneObj?.durationSec}s`}
                        </span>
                        {activeSceneObj && (
                          <span className="px-1.5 py-0.5 rounded bg-black/65 text-[9px] font-mono text-white/90 truncate max-w-[90px]">
                            {activeSceneObj.speaker}
                          </span>
                        )}
                      </div>

                      {/* Bottom Subtitle Overlay */}
                      <div className="relative z-10 p-2.5 bg-gradient-to-t from-black/90 via-black/60 to-transparent">
                        <p className="text-[11px] font-semibold text-white leading-snug line-clamp-3 drop-shadow">
                          {selectedStageFrame === 'thumbnail'
                            ? story.viralTitle
                            : activeSceneObj?.subtitle || activeSceneObj?.dialogue}
                        </p>
                      </div>
                    </div>

                    {/* Right Stage Meta & Production Action Controls */}
                    <div className="flex-1 min-w-0 w-full flex flex-col justify-between gap-3">
                      <div className="space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <h2
                              className="text-sm sm:text-base font-semibold text-[#F4F5F7] leading-snug"
                              style={{ fontFamily: 'var(--font-display)' }}
                            >
                              {story.viralTitle}
                            </h2>
                            <p className="text-[11px] text-[#9BA1AE] mt-0.5 line-clamp-2">
                              {story.comedyTwistNote}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={handleCopyTitleAndTags}
                            className="h-7 px-2 rounded-lg bg-white/6 border border-white/10 text-[10px] font-medium text-[#D1D5DF] hover:bg-white/10 inline-flex items-center gap-1 shrink-0"
                          >
                            {copiedMetaToast ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                            <span>{copiedMetaToast ? t.bhojpuriCopiedToast : 'Title & Tags'}</span>
                          </button>
                        </div>

                        <div className="flex flex-wrap gap-1.5">
                          {story.hashtags.map((tag) => (
                            <span
                              key={tag}
                              className="text-[10px] font-mono text-amber-300/90 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>

                        {/* Quick Frame Strip: Thumbnail + Scenes 1..N */}
                        <div className="flex items-center gap-1 overflow-x-auto pb-1">
                          <button
                            type="button"
                            onClick={() => setSelectedStageFrame('thumbnail')}
                            className={`h-7 px-2.5 rounded-lg text-[11px] font-medium whitespace-nowrap shrink-0 transition-colors ${
                              selectedStageFrame === 'thumbnail'
                                ? 'bg-rose-500/20 border border-rose-400/45 text-rose-200'
                                : 'bg-white/5 border border-white/10 text-[#9BA1AE] hover:text-white'
                            }`}
                          >
                            Thumb {story.thumbnailImageUrl ? '✓' : ''}
                          </button>
                          {story.scenes.map((scene) => {
                            const active = selectedStageFrame === scene.sceneNumber;
                            return (
                              <button
                                key={scene.sceneNumber}
                                type="button"
                                onClick={() => setSelectedStageFrame(scene.sceneNumber)}
                                className={`h-7 px-2 rounded-lg text-[11px] font-mono whitespace-nowrap shrink-0 transition-colors ${
                                  active
                                    ? 'bg-amber-500 text-[#0A0B0E] font-semibold'
                                    : activeSpeakingScene === scene.sceneNumber
                                      ? 'bg-emerald-500/25 border border-emerald-400/50 text-emerald-200'
                                      : 'bg-white/5 border border-white/10 text-[#9BA1AE] hover:text-white'
                                }`}
                              >
                                S{scene.sceneNumber}
                                {scene.imageUrl ? '✓' : ''}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Primary Studio Controls: Render 3D Art, Listen Dialogues, Open Google Flow */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <button
                            type="button"
                            onClick={() => void handleGenerateAll3DArt()}
                            className="h-9 px-3 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                          >
                            {isRenderingAllArt ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Palette className="w-3.5 h-3.5" />
                            )}
                            <span>
                              {isRenderingAllArt ? t.bhojpuriGenArtBusy : t.bhojpuriGenArtBtn}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={() => void handleListenAllDialogues()}
                            className={`h-9 px-3 rounded-xl border text-xs font-semibold transition-colors inline-flex items-center gap-1.5 whitespace-nowrap ${
                              isPlayingDialogues
                                ? 'bg-rose-500/22 border-rose-400/50 text-rose-200 hover:bg-rose-500/30'
                                : 'bg-white/6 border-white/12 text-[#F4F5F7] hover:bg-white/12'
                            }`}
                          >
                            {isPlayingDialogues ? (
                              <Square className="w-3 h-3 fill-current" />
                            ) : (
                              <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                            )}
                            <span>
                              {isPlayingDialogues ? t.stopMsg : t.bhojpuriListenDialogues}
                            </span>
                          </button>

                          <a
                            href={GOOGLE_FLOW_URL}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={handleCopyForGoogleFlow}
                            className="h-9 px-3 rounded-xl bg-sky-500/18 border border-sky-400/40 text-sky-200 text-xs font-semibold hover:bg-sky-500/26 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap"
                          >
                            <span>
                              {flowCopiedToast ? t.bhojpuriCopiedToast : t.bhojpuriOpenGoogleFlow}
                            </span>
                            <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                          </a>
                        </div>

                        {artProgressText && (
                          <p className="text-[11px] font-mono text-amber-300">{artProgressText}</p>
                        )}
                        {flowCopiedToast && (
                          <p className="text-[11px] text-emerald-300">
                            {t.bhojpuriCopiedToast} — Character-locked multi-scene prompt copied for
                            Google Flow (Veo).
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </section>

          {/* 1. Visual Bhojpuri Comedy Research Pipeline */}
          <section className="rounded-2xl studio-surface p-3.5 space-y-3">
            <form
              onSubmit={handleRunResearchPipeline}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2"
            >
              <div className="relative flex-1 min-w-0">
                <Search className="w-3.5 h-3.5 text-[#737A8A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={topicInput}
                  onChange={(e) => setTopicInput(e.target.value)}
                  placeholder={t.bhojpuriTopicPlaceholder}
                  disabled={isRunningPipeline}
                  className="w-full h-10 pl-8 pr-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs sm:text-sm text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
                />
              </div>

              <button
                type="submit"
                disabled={isRunningPipeline}
                className="h-10 px-4 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 disabled:opacity-50 transition-colors inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
              >
                {isRunningPipeline ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>
                  {isRunningPipeline ? t.bhojpuriResearching : t.bhojpuriResearchBtn}
                </span>
              </button>
            </form>

            {/* Visible 4-Step Live Pipeline Strip */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
              {pipelineSteps.map((step) => {
                const st = pipelineState[step.id];
                const stateClasses =
                  st.status === 'active'
                    ? 'bg-amber-500/15 border-amber-400/50 text-amber-200'
                    : st.status === 'done'
                      ? 'bg-emerald-500/12 border-emerald-400/35 text-emerald-200'
                      : st.status === 'error'
                        ? 'bg-rose-500/15 border-rose-400/40 text-rose-200'
                        : 'bg-[#0C0E13] border-white/8 text-[#8D94A3]';

                return (
                  <div
                    key={step.id}
                    className={`rounded-xl border px-2.5 py-2 transition-colors min-w-0 ${stateClasses}`}
                  >
                    <div className="flex items-center justify-between gap-1.5">
                      <span className="text-[11px] font-semibold truncate">{step.label}</span>
                      {st.status === 'active' && (
                        <Loader2 className="w-3 h-3 animate-spin shrink-0 text-amber-400" />
                      )}
                      {st.status === 'done' && (
                        <Check className="w-3 h-3 shrink-0 text-emerald-400" />
                      )}
                    </div>
                    {st.detail && (
                      <div className="text-[10px] opacity-80 truncate mt-0.5">{st.detail}</div>
                    )}
                  </div>
                );
              })}
            </div>

            {statusError && (
              <div className="rounded-xl bg-rose-950/35 border border-rose-500/30 px-3 py-2 flex items-center justify-between gap-2 flex-wrap">
                <p className="text-xs text-rose-200">{statusError}</p>
                {needsSecretsHint && (
                  <button
                    type="button"
                    onClick={onOpenSecrets}
                    className="h-7 px-2.5 rounded-lg bg-amber-500/20 border border-amber-400/45 text-amber-200 text-[11px] font-semibold inline-flex items-center gap-1 whitespace-nowrap"
                  >
                    <KeyRound className="w-3 h-3" />
                    <span>{t.openSecrets}</span>
                  </button>
                )}
              </div>
            )}

            {/* Live Web Research Findings Strip */}
            {story && story.researchSources.length > 0 && (
              <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-[#7D8596]">
                  Live Signals:
                </span>
                {story.researchSources.map((src) => (
                  <a
                    key={src.url}
                    href={src.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] text-amber-300/90 hover:text-amber-200 bg-white/5 border border-white/8 rounded-md px-2 py-0.5 inline-flex items-center gap-1 max-w-[200px] truncate"
                  >
                    <span className="truncate">{src.title}</span>
                    <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                  </a>
                ))}
              </div>
            )}
          </section>

          {/* 3. 4-Character Photo Vault with Gemini Vision DNA Lock */}
          <section className="rounded-2xl studio-surface overflow-hidden">
            <button
              type="button"
              onClick={() => setShowCharVault((v) => !v)}
              className="w-full px-3.5 py-2.5 bg-[#151821] border-b border-white/8 flex items-center justify-between gap-2 text-left"
            >
              <div className="flex items-center gap-2 min-w-0">
                <Users className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="text-xs sm:text-sm font-semibold text-[#F4F5F7] truncate">
                  {t.bhojpuriCharVault}
                </span>
                <span className="text-[11px] text-[#8D94A3] font-mono tabular-nums shrink-0">
                  {enabledChars.length} active · DNA Lock
                </span>
              </div>
              <ChevronDown
                className={`w-4 h-4 text-[#9BA1AE] transition-transform shrink-0 ${
                  showCharVault ? 'rotate-180' : ''
                }`}
              />
            </button>

            {/* Compact Cast Strip when collapsed */}
            {!showCharVault && (
              <div className="px-3.5 py-2.5 flex items-center gap-2 overflow-x-auto">
                {characters.map((c) => (
                  <div
                    key={c.slot}
                    className={`flex items-center gap-2 px-2.5 py-1.5 rounded-xl border shrink-0 ${
                      c.enabled
                        ? 'bg-[#0C0E13] border-amber-500/30 text-[#F4F5F7]'
                        : 'bg-[#0C0E13]/50 border-white/6 text-[#6F7686] opacity-60'
                    }`}
                  >
                    {c.photoDataUrl ? (
                      <img
                        src={c.photoDataUrl}
                        alt={c.name}
                        className="w-6 h-6 rounded-lg object-cover border border-white/15 shrink-0"
                      />
                    ) : (
                      <span className="w-6 h-6 rounded-lg bg-amber-500/15 text-amber-300 text-[11px] font-bold flex items-center justify-center shrink-0">
                        {c.slot}
                      </span>
                    )}
                    <div className="min-w-0">
                      <div className="text-[11px] font-semibold leading-tight">{c.name}</div>
                      <div className="text-[9px] font-mono text-[#8D94A3] leading-tight">
                        {c.voicePersona} · {c.dnaSource === 'vision' ? 'Vision DNA' : 'Locked'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Expanded 4-Slot Editable Character Photo Vault */}
            {showCharVault && (
              <div className="p-3.5 space-y-3 bg-[#0C0E13]">
                {charNotice && (
                  <div className="rounded-xl bg-amber-500/12 border border-amber-400/35 px-3 py-2 flex items-center justify-between gap-2 text-xs text-amber-200">
                    <span>{charNotice}</span>
                    <button
                      type="button"
                      onClick={() => setCharNotice(null)}
                      aria-label="Dismiss character notice"
                      className="text-amber-300 hover:text-white shrink-0"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {characters.map((char) => {
                    const isExtracting = extractingSlot === char.slot;
                    return (
                      <div
                        key={char.slot}
                        className={`rounded-xl border p-3 space-y-2.5 transition-colors ${
                          char.enabled
                            ? 'bg-[#12151E] border-white/12'
                            : 'bg-[#0F1117] border-white/6 opacity-65'
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          {/* Photo Preview + Upload Trigger */}
                          <label className="relative w-14 h-14 rounded-xl bg-[#0A0B0E] border border-white/12 overflow-hidden flex flex-col items-center justify-center cursor-pointer hover:border-amber-400/60 shrink-0 group">
                            {char.photoDataUrl ? (
                              <img
                                src={char.photoDataUrl}
                                alt={char.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <>
                                <Upload className="w-4 h-4 text-amber-400/80" />
                                <span className="text-[9px] text-[#8D94A3] mt-0.5">Photo</span>
                              </>
                            )}
                            {isExtracting && (
                              <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
                                <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                              </div>
                            )}
                            <input
                              type="file"
                              accept="image/*"
                              className="sr-only"
                              onChange={(e) => {
                                const file = e.target.files?.[0] ?? null;
                                void handlePhotoUpload(char.slot, file);
                                e.target.value = '';
                              }}
                            />
                          </label>

                          {/* Name, Enable Toggle, Voice Selector */}
                          <div className="flex-1 min-w-0 space-y-1.5">
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                value={char.name}
                                onChange={(e) =>
                                  updateCharacterSlot(char.slot, (c) => ({
                                    ...c,
                                    name: e.target.value,
                                    updatedAt: Date.now(),
                                  }))
                                }
                                aria-label={`Character slot ${char.slot} name`}
                                className="flex-1 min-w-0 h-8 px-2.5 rounded-lg bg-[#0A0B0E] border border-white/10 text-xs font-semibold text-[#F4F5F7] focus:outline-none focus:border-amber-400/70"
                              />
                              <button
                                type="button"
                                onClick={() => handleToggleCharacterEnabled(char.slot)}
                                aria-pressed={char.enabled}
                                className={`h-8 px-2.5 rounded-lg text-[11px] font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                                  char.enabled
                                    ? 'bg-emerald-500/18 border-emerald-400/40 text-emerald-200'
                                    : 'bg-white/5 border-white/10 text-[#8D94A3]'
                                }`}
                              >
                                {char.enabled ? 'ON' : 'OFF'}
                              </button>
                            </div>

                            <div className="flex items-center gap-1.5 flex-wrap">
                              <select
                                value={char.voicePersona}
                                onChange={(e) =>
                                  updateCharacterSlot(char.slot, (c) => ({
                                    ...c,
                                    voicePersona: e.target.value as VoicePersona,
                                    updatedAt: Date.now(),
                                  }))
                                }
                                aria-label={`${char.name} voice persona`}
                                className="h-7 px-2 rounded-lg bg-[#0A0B0E] border border-white/10 text-[11px] font-mono text-amber-300 focus:outline-none focus:border-amber-400/70"
                              >
                                {VOICE_PERSONAS.map((v) => (
                                  <option key={v} value={v}>
                                    Voice: {v}
                                  </option>
                                ))}
                              </select>

                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/12 border border-amber-400/25 text-[10px] font-medium text-amber-200">
                                <Lock className="w-2.5 h-2.5" />
                                <span>
                                  {isExtracting
                                    ? t.bhojpuriExtractingDna
                                    : char.dnaSource === 'vision'
                                      ? 'Vision DNA Locked'
                                      : t.bhojpuriDnaLocked}
                                </span>
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Locked Character DNA Textarea */}
                        <textarea
                          value={char.dnaDescription}
                          onChange={(e) =>
                            updateCharacterSlot(char.slot, (c) => ({
                              ...c,
                              dnaDescription: e.target.value,
                              dnaLocked: true,
                              dnaSource: 'manual',
                              updatedAt: Date.now(),
                            }))
                          }
                          rows={2}
                          aria-label={`${char.name} locked Character DNA`}
                          className="w-full p-2 rounded-lg bg-[#0A0B0E] border border-white/8 text-[11px] text-[#D1D5DF] leading-relaxed focus:outline-none focus:border-amber-400/60 resize-none"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </section>

          {/* 2. Motu-Patlu Style Bhojpuri Comedy Storyboard & Thumbnail Prompt */}
          {story && (
            <section className="space-y-3">
              {/* Thumbnail Prompt & Quick Render Strip */}
              <div className="rounded-2xl studio-surface p-3.5 space-y-2">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-300">
                    <ImageIcon className="w-3.5 h-3.5 shrink-0" />
                    <span>{t.bhojpuriThumbnailLabel}</span>
                    {story.providerUsed && (
                      <span className="font-mono text-[10px] text-[#8D94A3] font-normal">
                        · {story.providerUsed}
                      </span>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => void handleGenerateSingleArt('thumbnail')}
                    disabled={isRenderingAllArt || Boolean(renderingSingleTarget)}
                    className="h-7 px-2.5 rounded-lg bg-amber-500/18 border border-amber-400/40 text-amber-200 text-[11px] font-semibold hover:bg-amber-500/28 disabled:opacity-40 inline-flex items-center gap-1 whitespace-nowrap"
                  >
                    {renderingSingleTarget === 'thumbnail' ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <Palette className="w-3 h-3" />
                    )}
                    <span>Render Thumbnail</span>
                  </button>
                </div>
                <p className="text-[11px] text-[#B7BDC9] leading-relaxed font-mono bg-[#0A0B0E] border border-white/8 rounded-xl p-2.5">
                  {story.thumbnailPrompt}
                </p>
              </div>

              {/* Scene-by-Scene Storyboard Header */}
              <div className="flex items-center justify-between gap-2 px-0.5">
                <h2
                  className="text-xs sm:text-sm font-semibold text-[#F4F5F7]"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  {t.bhojpuriScenesLabel} ({story.scenes.length} · {story.totalDurationSec}s)
                </h2>
                <button
                  type="button"
                  onClick={handleCopyForGoogleFlow}
                  className="text-[11px] font-medium text-amber-300 hover:text-amber-200 inline-flex items-center gap-1"
                >
                  {flowCopiedToast ? (
                    <Check className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <Copy className="w-3 h-3" />
                  )}
                  <span>{flowCopiedToast ? t.bhojpuriCopiedToast : 'Copy Flow Prompt'}</span>
                </button>
              </div>

              {/* Scene Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {story.scenes.map((scene) => {
                  const isSpeakingThis = activeSpeakingScene === scene.sceneNumber;
                  const isRenderingThis =
                    renderingSingleTarget === `scene_${scene.sceneNumber}`;

                  return (
                    <article
                      key={scene.sceneNumber}
                      className={`rounded-2xl studio-surface p-3.5 space-y-2.5 transition-colors ${
                        isSpeakingThis
                          ? 'ring-1 ring-amber-400/70'
                          : selectedStageFrame === scene.sceneNumber
                            ? 'ring-1 ring-white/20'
                            : ''
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
                          <span className="px-2 py-0.5 rounded-md bg-amber-500/18 border border-amber-400/35 text-[10px] font-mono font-semibold text-amber-300 tabular-nums">
                            Scene {scene.sceneNumber} · {scene.durationSec}s
                          </span>
                          <span className="text-xs font-semibold text-[#F4F5F7] truncate">
                            {scene.speaker}
                          </span>
                          <span className="text-[10px] font-mono text-[#8D94A3]">
                            ({scene.voicePersona})
                          </span>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => void handleListenSingleScene(scene)}
                            aria-label={`Listen to Scene ${scene.sceneNumber} dialogue`}
                            className={`h-7 px-2 rounded-lg border text-[11px] font-semibold inline-flex items-center gap-1 ${
                              isSpeakingThis
                                ? 'bg-rose-500/20 border-rose-400/45 text-rose-200'
                                : 'bg-white/6 border-white/10 text-[#E5E8F0] hover:bg-white/12'
                            }`}
                          >
                            {isSpeakingThis ? (
                              <Square className="w-2.5 h-2.5 fill-current" />
                            ) : (
                              <Volume2 className="w-3 h-3 text-amber-400" />
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => void handleGenerateSingleArt(scene)}
                            disabled={isRenderingAllArt || Boolean(renderingSingleTarget)}
                            aria-label={`Render Scene ${scene.sceneNumber} 3D frame`}
                            className="h-7 px-2 rounded-lg bg-white/6 border border-white/10 text-[11px] font-medium text-[#E5E8F0] hover:bg-white/12 disabled:opacity-40 inline-flex items-center gap-1"
                          >
                            {isRenderingThis ? (
                              <Loader2 className="w-3 h-3 animate-spin text-amber-400" />
                            ) : (
                              <Palette className="w-3 h-3 text-amber-400" />
                            )}
                          </button>
                        </div>
                      </div>

                      <div className="flex items-start gap-2.5">
                        {scene.imageUrl && (
                          <button
                            type="button"
                            onClick={() => setSelectedStageFrame(scene.sceneNumber)}
                            className="w-16 h-24 rounded-lg overflow-hidden border border-white/12 shrink-0 bg-[#0A0B0E]"
                          >
                            <img
                              src={scene.imageUrl}
                              alt={`Scene ${scene.sceneNumber}`}
                              className="w-full h-full object-cover"
                            />
                          </button>
                        )}

                        <div className="flex-1 min-w-0 space-y-1.5">
                          <p className="text-xs sm:text-[13px] text-[#F4F5F7] leading-relaxed font-medium">
                            “{scene.dialogue}”
                          </p>
                          <div className="flex items-center gap-1.5 flex-wrap text-[10px]">
                            <span className="px-1.5 py-0.5 rounded bg-white/6 text-[#C4C9D4]">
                              CC: {scene.subtitle}
                            </span>
                            <span className="px-1.5 py-0.5 rounded bg-rose-500/12 text-rose-200/90 font-mono">
                              SFX: {scene.sfxCue}
                            </span>
                          </div>
                        </div>
                      </div>

                      <p className="text-[10px] font-mono text-[#8D94A3] leading-relaxed bg-[#0A0B0E] border border-white/6 rounded-lg p-2 line-clamp-3">
                        {scene.visualPrompt}
                      </p>
                    </article>
                  );
                })}
              </div>
            </section>
          )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
