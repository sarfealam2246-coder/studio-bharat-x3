import { Language, VoicePersona, VoiceSpeed } from '../types/studio';
import { studioBus } from './eventBus';
import { loadSecretsVault } from './secretsService';

export const VOICE_PERSONAS: VoicePersona[] = ['Aoede', 'Kore', 'Puck', 'Charon'];
export const VOICE_SPEEDS: VoiceSpeed[] = [1.0, 1.15, 1.25, 1.5];

const TTS_MODEL = 'gemini-3.8-flash-tts';
const PER_KEY_TIMEOUT_MS = 4000;
const KEY_COOLDOWN_MS = 45_000;
const PCM_SAMPLE_RATE = 24_000;
const VOICE_BUSY_NOTICE = 'Voice key busy — tap 🔊 to retry';

export type StudioSpeakResult = 'gemini-tts' | 'cancelled' | 'none';

export interface SpeakOptions {
  persona?: VoicePersona;
  speed?: VoiceSpeed;
  language?: Language;
  messageId?: string | null;
}

interface KeySlot {
  slotIndex: number; // 0, 1, 2 -> Gemini Key 1..3
  apiKey: string;
}

// Round-robin cursor & per-key 45s cooldown tracker (429 / 503)
let roundRobinCursor = 0;
const keyCooldownUntil = new Map<number, number>();

// Active playback & in-flight request references
let sharedAudioCtx: AudioContext | null = null;
let activeAbortController: AbortController | null = null;
let activeSourceNode: AudioBufferSourceNode | null = null;
let activePlaybackResolve: ((completed: boolean) => void) | null = null;
let speaking = false;
let currentMessageId: string | null = null;
let playbackGeneration = 0;

function getOrderedGeminiSlots(): KeySlot[] {
  const vault = loadSecretsVault();
  const configured: KeySlot[] = [];
  vault.geminiKeys.forEach((raw, idx) => {
    const trimmed = raw.trim();
    if (trimmed) {
      configured.push({ slotIndex: idx, apiKey: trimmed });
    }
  });
  if (configured.length === 0) return [];

  const startOffset = roundRobinCursor % configured.length;
  roundRobinCursor = (roundRobinCursor + 1) % configured.length;

  const rotated = [
    ...configured.slice(startOffset),
    ...configured.slice(0, startOffset),
  ];

  const now = Date.now();
  return rotated.filter((slot) => {
    const until = keyCooldownUntil.get(slot.slotIndex) ?? 0;
    return now >= until;
  });
}

function markKeyCooldown(slotIndex: number): void {
  keyCooldownUntil.set(slotIndex, Date.now() + KEY_COOLDOWN_MS);
}

function getOrCreateAudioContext(): AudioContext {
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!sharedAudioCtx || sharedAudioCtx.state === 'closed') {
    sharedAudioCtx = new AudioCtx({ sampleRate: PCM_SAMPLE_RATE });
  }
  return sharedAudioCtx;
}

function base64ToUint8Array(base64: string): Uint8Array {
  const binary = window.atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function isWavRiffHeader(bytes: Uint8Array): boolean {
  return (
    bytes.byteLength > 44 &&
    bytes[0] === 0x52 && // R
    bytes[1] === 0x49 && // I
    bytes[2] === 0x46 && // F
    bytes[3] === 0x46 // F
  );
}

function pcm16ToAudioBuffer(
  audioCtx: AudioContext,
  pcmBytes: Uint8Array,
  sampleRate = PCM_SAMPLE_RATE
): AudioBuffer {
  const byteOffset = pcmBytes.byteOffset;
  const evenLength = pcmBytes.byteLength - (pcmBytes.byteLength % 2);
  const sampleCount = evenLength / 2;
  const view = new DataView(pcmBytes.buffer, byteOffset, evenLength);
  const audioBuffer = audioCtx.createBuffer(1, Math.max(1, sampleCount), sampleRate);
  const channel = audioBuffer.getChannelData(0);
  for (let i = 0; i < sampleCount; i++) {
    channel[i] = view.getInt16(i * 2, true) / 32768;
  }
  return audioBuffer;
}

async function decodeGeminiAudio(
  audioCtx: AudioContext,
  base64Data: string,
  mimeType: string
): Promise<AudioBuffer> {
  const bytes = base64ToUint8Array(base64Data);
  const looksLikeWav = mimeType.toLowerCase().includes('wav') || isWavRiffHeader(bytes);

  if (looksLikeWav) {
    try {
      const copy = new ArrayBuffer(bytes.byteLength);
      new Uint8Array(copy).set(bytes);
      return await audioCtx.decodeAudioData(copy);
    } catch {
      // Fallback: strip standard 44-byte RIFF WAV header and decode raw 24kHz PCM16
      const pcmPayload = isWavRiffHeader(bytes) ? bytes.subarray(44) : bytes;
      return pcm16ToAudioBuffer(audioCtx, pcmPayload, PCM_SAMPLE_RATE);
    }
  }

  return pcm16ToAudioBuffer(audioCtx, bytes, PCM_SAMPLE_RATE);
}

interface TtsAttemptSuccess {
  ok: true;
  base64Audio: string;
  mimeType: string;
}

interface TtsAttemptFailure {
  ok: false;
  abortedByStop: boolean;
  rateLimitedOrBusy: boolean;
}

async function fetchTtsWithKey(
  apiKey: string,
  text: string,
  persona: VoicePersona,
  generation: number
): Promise<TtsAttemptSuccess | TtsAttemptFailure> {
  const controller = new AbortController();
  activeAbortController = controller;

  let timedOut = false;
  const timeoutId = window.setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, PER_KEY_TIMEOUT_MS);

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${TTS_MODEL}:generateContent?key=${encodeURIComponent(apiKey)}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      signal: controller.signal,
      body: JSON.stringify({
        contents: [
          {
            role: 'user',
            parts: [{ text }],
          },
        ],
        generationConfig: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: persona,
              },
            },
          },
        },
      }),
    });

    if (generation !== playbackGeneration) {
      return { ok: false, abortedByStop: true, rateLimitedOrBusy: false };
    }

    if (response.status === 429 || response.status === 503) {
      return { ok: false, abortedByStop: false, rateLimitedOrBusy: true };
    }

    if (!response.ok) {
      return { ok: false, abortedByStop: false, rateLimitedOrBusy: false };
    }

    const payload = (await response.json()) as {
      candidates?: Array<{
        content?: {
          parts?: Array<{
            inlineData?: { data?: string; mimeType?: string };
          }>;
        };
      }>;
    };

    const parts = payload.candidates?.[0]?.content?.parts ?? [];
    const audioPart = parts.find((p) => Boolean(p.inlineData?.data));
    const base64Audio = audioPart?.inlineData?.data;
    if (!base64Audio) {
      return { ok: false, abortedByStop: false, rateLimitedOrBusy: false };
    }

    return {
      ok: true,
      base64Audio,
      mimeType: audioPart?.inlineData?.mimeType ?? 'audio/wav',
    };
  } catch {
    if (generation !== playbackGeneration) {
      return { ok: false, abortedByStop: true, rateLimitedOrBusy: false };
    }
    return {
      ok: false,
      abortedByStop: false,
      rateLimitedOrBusy: timedOut,
    };
  } finally {
    window.clearTimeout(timeoutId);
    if (activeAbortController === controller) {
      activeAbortController = null;
    }
  }
}

function playDecodedBuffer(
  audioCtx: AudioContext,
  buffer: AudioBuffer,
  speed: VoiceSpeed,
  generation: number
): Promise<boolean> {
  return new Promise<boolean>((resolve) => {
    if (generation !== playbackGeneration) {
      resolve(false);
      return;
    }

    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = Math.min(1.5, Math.max(1.0, speed));
    source.connect(audioCtx.destination);

    activeSourceNode = source;
    activePlaybackResolve = resolve;

    const finish = (completed: boolean) => {
      if (activeSourceNode === source) {
        activeSourceNode = null;
      }
      if (activePlaybackResolve === resolve) {
        activePlaybackResolve = null;
      }
      try {
        source.disconnect();
      } catch {
        // Ignore already-disconnected nodes.
      }
      resolve(completed);
    };

    source.onended = () => finish(generation === playbackGeneration);

    try {
      source.start(0);
    } catch {
      finish(false);
    }
  });
}

export function isStudioSpeechActive(): boolean {
  return speaking;
}

export function getSpeakingMessageId(): string | null {
  return currentMessageId;
}

export function stopStudioSpeech(): void {
  playbackGeneration += 1;

  if (activeAbortController) {
    try {
      activeAbortController.abort();
    } catch {
      // Ignore abort errors.
    }
    activeAbortController = null;
  }

  if (activeSourceNode) {
    try {
      activeSourceNode.onended = null;
      activeSourceNode.stop();
      activeSourceNode.disconnect();
    } catch {
      // Ignore stop errors on already-ended nodes.
    }
    activeSourceNode = null;
  }

  if (activePlaybackResolve) {
    const done = activePlaybackResolve;
    activePlaybackResolve = null;
    done(false);
  }

  if (speaking || currentMessageId !== null) {
    speaking = false;
    currentMessageId = null;
    studioBus.emit('voice:speakingChange', { speaking: false, messageId: null });
  }
}

export async function speakWithStudioVoice(
  rawText: string,
  options: SpeakOptions = {}
): Promise<StudioSpeakResult> {
  const cleanText = rawText.replace(/[*_`#]+/g, '').trim();
  if (!cleanText) return 'none';

  // Cancel any previous speech cleanly before starting
  stopStudioSpeech();

  const generation = playbackGeneration;
  const persona: VoicePersona = options.persona ?? 'Aoede';
  const speed: VoiceSpeed = options.speed ?? 1.0;
  const messageId = options.messageId ?? null;

  speaking = true;
  currentMessageId = messageId;
  studioBus.emit('voice:speakingChange', { speaking: true, messageId });

  try {
    const slots = getOrderedGeminiSlots();
    if (slots.length === 0) {
      studioBus.emit('voice:notice', {
        message: VOICE_BUSY_NOTICE,
        level: 'warning',
      });
      return 'none';
    }

    let audioPayload: TtsAttemptSuccess | null = null;

    for (const slot of slots) {
      if (generation !== playbackGeneration) {
        return 'cancelled';
      }

      const attempt = await fetchTtsWithKey(slot.apiKey, cleanText, persona, generation);
      if (attempt.ok) {
        audioPayload = attempt;
        break;
      }

      if (attempt.abortedByStop || generation !== playbackGeneration) {
        return 'cancelled';
      }

      if (attempt.rateLimitedOrBusy) {
        markKeyCooldown(slot.slotIndex);
      }
    }

    if (!audioPayload) {
      // NO ROBOTIC TTS RULE: never fall back to window.speechSynthesis or Android native TTS.
      studioBus.emit('voice:notice', {
        message: VOICE_BUSY_NOTICE,
        level: 'warning',
      });
      return 'none';
    }

    if (generation !== playbackGeneration) {
      return 'cancelled';
    }

    const audioCtx = getOrCreateAudioContext();
    if (audioCtx.state === 'suspended') {
      await audioCtx.resume();
    }

    const decoded = await decodeGeminiAudio(
      audioCtx,
      audioPayload.base64Audio,
      audioPayload.mimeType
    );

    if (generation !== playbackGeneration) {
      return 'cancelled';
    }

    const completed = await playDecodedBuffer(audioCtx, decoded, speed, generation);
    return completed ? 'gemini-tts' : 'cancelled';
  } catch {
    if (generation !== playbackGeneration) {
      return 'cancelled';
    }
    studioBus.emit('voice:notice', {
      message: VOICE_BUSY_NOTICE,
      level: 'warning',
    });
    return 'none';
  } finally {
    if (generation === playbackGeneration) {
      speaking = false;
      currentMessageId = null;
      studioBus.emit('voice:speakingChange', { speaking: false, messageId: null });
    }
  }
}

/**
 * Synthesizes an AudioBuffer via the 3-key Gemini TTS load-balancer for offline/local
 * MediaRecorder video muxing without interrupting live playback or using robotic TTS.
 */
export async function synthesizeStudioVoiceBuffer(
  rawText: string,
  persona: VoicePersona,
  targetAudioCtx: AudioContext
): Promise<AudioBuffer | null> {
  const cleanText = rawText.replace(/[*_`#]+/g, '').trim();
  if (!cleanText) return null;

  const slots = getOrderedGeminiSlots();
  if (slots.length === 0) return null;

  for (const slot of slots) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), PER_KEY_TIMEOUT_MS + 2500);
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${TTS_MODEL}:generateContent?key=${encodeURIComponent(
        slot.apiKey
      )}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: cleanText }] }],
          generationConfig: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: persona },
              },
            },
          },
        }),
      });

      if (res.status === 429 || res.status === 503) {
        markKeyCooldown(slot.slotIndex);
        continue;
      }
      if (!res.ok) continue;

      const payload = (await res.json()) as {
        candidates?: Array<{
          content?: {
            parts?: Array<{ inlineData?: { data?: string; mimeType?: string } }>;
          };
        }>;
      };
      const audioPart = payload.candidates?.[0]?.content?.parts?.find((p) =>
        Boolean(p.inlineData?.data)
      );
      const b64 = audioPart?.inlineData?.data;
      if (!b64) continue;

      return await decodeGeminiAudio(
        targetAudioCtx,
        b64,
        audioPart?.inlineData?.mimeType ?? 'audio/wav'
      );
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        markKeyCooldown(slot.slotIndex);
      }
    } finally {
      window.clearTimeout(timer);
    }
  }

  return null;
}
