import {
  BrainPreference,
  DepartmentId,
  Language,
  LockedStepPlan,
  VedaMessage,
} from '../types/studio';
import { buildDynamicSkillsPromptContext } from './dynamicToolsService';
import { buildMemoryPromptContext } from './memoryService';
import { loadSecretsVault } from './secretsService';

const ATTEMPT_TIMEOUT_MS = 8000;
const KEY_COOLDOWN_MS = 60_000;
const GEMINI_TEXT_MODEL = 'gemini-4-hydrogen';

export const BRAIN_OPTIONS: Array<{ id: BrainPreference; label: string }> = [
  { id: 'auto', label: 'Auto' },
  { id: 'gemini', label: 'Gemini' },
  { id: 'groq', label: 'Groq' },
  { id: 'nvidia', label: 'NVIDIA' },
  { id: 'cloudflare', label: 'Cloudflare' },
];

interface ProviderCandidate {
  keyId: string;
  group: 'gemini' | 'groq' | 'nvidia' | 'cloudflare' | 'other';
  displayName: string;
  apiKey: string;
  endpoint?: string;
  model: string;
  kind: 'gemini' | 'openai_compat';
}

export interface AiRouterRequest {
  userMessage: string;
  normalizedMessage: string;
  history: VedaMessage[];
  language: Language;
  brainPreference: BrainPreference;
  researchContext?: string;
  requestLockedPlan?: boolean;
  planDepartmentHint?: DepartmentId;
}

export interface AiRouterResponse {
  ok: boolean;
  reply: string;
  providerUsed?: string;
  learnedRule?: string;
  routeDepartment?: DepartmentId;
  lockedPlan?: LockedStepPlan;
  noKeysConfigured?: boolean;
}

const keyCooldownUntil = new Map<string, number>();
let roundRobinOffset = 0;

function markKeyCooldown(keyId: string): void {
  keyCooldownUntil.set(keyId, Date.now() + KEY_COOLDOWN_MS);
}

function isKeyCooledDown(keyId: string): boolean {
  const until = keyCooldownUntil.get(keyId) ?? 0;
  return Date.now() < until;
}

function collectAllCandidates(): ProviderCandidate[] {
  const vault = loadSecretsVault();
  const list: ProviderCandidate[] = [];

  vault.geminiKeys.forEach((raw, idx) => {
    const apiKey = raw.trim();
    if (apiKey) {
      list.push({
        keyId: `gemini_${idx + 1}`,
        group: 'gemini',
        displayName: `Gemini Key ${idx + 1}`,
        apiKey,
        model: GEMINI_TEXT_MODEL,
        kind: 'gemini',
      });
    }
  });

  vault.otherAiKeys.forEach((entry) => {
    const apiKey = entry.apiKey.trim();
    if (!apiKey) return;
    const group: ProviderCandidate['group'] =
      entry.provider === 'groq'
        ? 'groq'
        : entry.provider === 'nvidia_nim'
          ? 'nvidia'
          : entry.provider === 'cloudflare_ai'
            ? 'cloudflare'
            : 'other';

    list.push({
      keyId: `other_${entry.id}`,
      group,
      displayName: entry.label || entry.provider.toUpperCase(),
      apiKey,
      endpoint: entry.endpoint.trim(),
      model: entry.model.trim() || 'default',
      kind: 'openai_compat',
    });
  });

  return list;
}

function prioritizeCandidates(
  all: ProviderCandidate[],
  preference: BrainPreference
): ProviderCandidate[] {
  const ready = all.filter((c) => !isKeyCooledDown(c.keyId));
  const pool = ready.length > 0 ? ready : all;
  if (pool.length === 0) return [];

  const offset = roundRobinOffset % pool.length;
  roundRobinOffset = (roundRobinOffset + 1) % pool.length;
  const rotated = [...pool.slice(offset), ...pool.slice(0, offset)];

  if (preference === 'auto') {
    return rotated;
  }

  const preferred = rotated.filter((c) => c.group === preference);
  const fallbacks = rotated.filter((c) => c.group !== preference);
  return [...preferred, ...fallbacks];
}

function buildSystemInstruction(req: AiRouterRequest): string {
  const memoryBlock = buildMemoryPromptContext();
  const skillsBlock = buildDynamicSkillsPromptContext();
  const langGuide =
    req.language === 'hi'
      ? 'Primary UI language is Hindi. Match the user naturally in Hindi, Hinglish, Bhojpuri, or English depending on how they speak.'
      : 'Primary UI language is English. Match the user naturally in English, Hinglish, Hindi, or Bhojpuri depending on how they speak.';

  const parts = [
    `You are VEDA — the serious, flagship, open-brain studio director inside STUDIO BHARAT X.`,
    `STYLE & VOICE RULES:
- Respond naturally, seriously, thoroughly, and clearly with real practical depth.
- NEVER artificially truncate or shorten your answers.
- NEVER tell unsolicited jokes, filler puns, or flippant banter.
- ${langGuide}
- VOICE-TO-TEXT REPAIR: The user often dictates in Hindi/Hinglish and STT mishears technical terms. Always infer true technical intent silently (e.g. "इन मीडिया"/"एनवीडिया" = NVIDIA, "ग्रो" = Groq, "सिगरेट"/"सीक्रेट" = Secrets, "अमल" = YAML, "गिठब" = GitHub, "क्लाउड फ्लेयर" = Cloudflare, "जेमिनी" = Gemini).`,
    memoryBlock,
    skillsBlock,
    req.researchContext || '',
    `OUTPUT FORMAT:
Return a single valid JSON object (no markdown fences needed, though JSON inside fences is fine) with this exact shape:
{
  "reply": "Your complete, natural, thorough response to the user.",
  "learnedRule": null or "A concise permanent user preference/rule if the user clearly stated a lasting preference or instruction, otherwise null",
  "routeDepartment": null or one of "gaming" | "apps" | "bhojpuri" | "agent" ONLY when the user clearly asked to open/switch into that department,
  "lockedPlan": ${
    req.requestLockedPlan
      ? `{ "title": "Concise plan title", "department": "${req.planDepartmentHint ?? 'apps'}", "steps": [{ "stepNumber": 1, "title": "Step title", "detail": "Concrete actionable detail" }] } (include 4-6 crisp steps)`
      : 'null (unless the user explicitly asked for a step-by-step locked plan)'
  }
}`,
  ];

  return parts.filter(Boolean).join('\n\n');
}

function buildChatTranscriptHistory(history: VedaMessage[]): Array<{ role: 'user' | 'assistant'; content: string }> {
  return history
    .slice(-8)
    .filter((m) => m.id !== 'veda_welcome')
    .map((m) => ({
      role: m.role === 'user' ? 'user' : 'assistant',
      content: m.text.slice(0, 1200),
    }));
}

async function fetchWithEightSecTimeout(url: string, init: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), ATTEMPT_TIMEOUT_MS);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timer);
  }
}

async function callGeminiCandidate(
  candidate: ProviderCandidate,
  systemInstruction: string,
  req: AiRouterRequest
): Promise<{ ok: true; rawText: string } | { ok: false; shouldCooldown: boolean }> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${candidate.model}:generateContent?key=${encodeURIComponent(
    candidate.apiKey
  )}`;

  const contents = [
    ...buildChatTranscriptHistory(req.history).map((m) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }],
    })),
    {
      role: 'user',
      parts: [{ text: req.normalizedMessage }],
    },
  ];

  try {
    const res = await fetchWithEightSecTimeout(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{ text: systemInstruction }],
        },
        contents,
        generationConfig: {
          responseMimeType: 'application/json',
        },
      }),
    });

    if (res.status === 429 || res.status === 503) {
      return { ok: false, shouldCooldown: true };
    }
    if (!res.ok) {
      return { ok: false, shouldCooldown: false };
    }

    const data = (await res.json()) as {
      candidates?: Array<{
        content?: { parts?: Array<{ text?: string }> };
      }>;
    };
    const text =
      data.candidates?.[0]?.content?.parts
        ?.map((p) => p.text ?? '')
        .join('')
        .trim() ?? '';
    if (!text) return { ok: false, shouldCooldown: false };
    return { ok: true, rawText: text };
  } catch (err) {
    const timedOut = err instanceof DOMException && err.name === 'AbortError';
    return { ok: false, shouldCooldown: timedOut };
  }
}

function resolveOpenAiChatEndpoint(rawEndpoint: string): string | null {
  const clean = rawEndpoint.trim().replace(/\/+$/, '');
  if (!clean) return null;
  try {
    const parsed = new URL(clean);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return null;
  } catch {
    return null;
  }
  if (clean.endsWith('/chat/completions')) return clean;
  if (clean.includes('api.cloudflare.com') && clean.endsWith('/tokens/verify')) {
    // Token verify endpoint is not a chat completion endpoint
    return null;
  }
  return `${clean}/chat/completions`;
}

async function callOpenAiCompatCandidate(
  candidate: ProviderCandidate,
  systemInstruction: string,
  req: AiRouterRequest
): Promise<{ ok: true; rawText: string } | { ok: false; shouldCooldown: boolean }> {
  const endpoint = resolveOpenAiChatEndpoint(candidate.endpoint || '');
  if (!endpoint) {
    return { ok: false, shouldCooldown: false };
  }

  const messages = [
    { role: 'system', content: systemInstruction },
    ...buildChatTranscriptHistory(req.history),
    { role: 'user', content: req.normalizedMessage },
  ];

  try {
    const res = await fetchWithEightSecTimeout(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${candidate.apiKey}`,
      },
      body: JSON.stringify({
        model: candidate.model,
        messages,
      }),
    });

    if (res.status === 429 || res.status === 503) {
      return { ok: false, shouldCooldown: true };
    }
    if (!res.ok) {
      return { ok: false, shouldCooldown: false };
    }

    const data = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const text = data.choices?.[0]?.message?.content?.trim() ?? '';
    if (!text) return { ok: false, shouldCooldown: false };
    return { ok: true, rawText: text };
  } catch (err) {
    const timedOut = err instanceof DOMException && err.name === 'AbortError';
    return { ok: false, shouldCooldown: timedOut };
  }
}

function parseStructuredAiOutput(
  rawText: string,
  fallbackDept?: DepartmentId
): {
  reply: string;
  learnedRule?: string;
  routeDepartment?: DepartmentId;
  lockedPlan?: LockedStepPlan;
} {
  const stripped = rawText
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();

  const tryParse = (str: string): Record<string, unknown> | null => {
    try {
      const parsed = JSON.parse(str);
      return parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : null;
    } catch {
      return null;
    }
  };

  let obj = tryParse(stripped);
  if (!obj) {
    const start = stripped.indexOf('{');
    const end = stripped.lastIndexOf('}');
    if (start !== -1 && end > start) {
      obj = tryParse(stripped.slice(start, end + 1));
    }
  }

  if (!obj || typeof obj.reply !== 'string') {
    return { reply: rawText.trim() };
  }

  const validDepts: DepartmentId[] = ['gaming', 'apps', 'bhojpuri', 'agent'];
  const routeDepartment =
    typeof obj.routeDepartment === 'string' &&
    validDepts.includes(obj.routeDepartment as DepartmentId)
      ? (obj.routeDepartment as DepartmentId)
      : undefined;

  const learnedRule =
    typeof obj.learnedRule === 'string' && obj.learnedRule.trim().length >= 4
      ? obj.learnedRule.trim()
      : undefined;

  let lockedPlan: LockedStepPlan | undefined;
  if (obj.lockedPlan && typeof obj.lockedPlan === 'object') {
    const lp = obj.lockedPlan as {
      title?: unknown;
      department?: unknown;
      steps?: unknown;
    };
    if (Array.isArray(lp.steps) && lp.steps.length > 0) {
      const dept: DepartmentId =
        typeof lp.department === 'string' && validDepts.includes(lp.department as DepartmentId)
          ? (lp.department as DepartmentId)
          : fallbackDept ?? 'apps';

      const steps = lp.steps
        .map((s, idx) => {
          const item = s as { stepNumber?: unknown; title?: unknown; detail?: unknown };
          const title = typeof item.title === 'string' ? item.title.trim() : `Step ${idx + 1}`;
          const detail = typeof item.detail === 'string' ? item.detail.trim() : '';
          return {
            stepNumber: typeof item.stepNumber === 'number' ? item.stepNumber : idx + 1,
            title,
            detail,
          };
        })
        .filter((s) => s.title || s.detail)
        .slice(0, 8);

      if (steps.length > 0) {
        lockedPlan = {
          id: `plan_${Date.now().toString(36)}`,
          title:
            typeof lp.title === 'string' && lp.title.trim()
              ? lp.title.trim()
              : 'Locked Studio Plan',
          department: dept,
          steps,
          createdAt: Date.now(),
        };
      }
    }
  }

  return {
    reply: obj.reply.trim(),
    learnedRule,
    routeDepartment,
    lockedPlan,
  };
}

export async function runVedaAiRouter(req: AiRouterRequest): Promise<AiRouterResponse> {
  const allCandidates = collectAllCandidates();
  if (allCandidates.length === 0) {
    return {
      ok: false,
      reply: '',
      noKeysConfigured: true,
    };
  }

  const ordered = prioritizeCandidates(allCandidates, req.brainPreference);
  const systemInstruction = buildSystemInstruction(req);

  for (const candidate of ordered) {
    const attempt =
      candidate.kind === 'gemini'
        ? await callGeminiCandidate(candidate, systemInstruction, req)
        : await callOpenAiCompatCandidate(candidate, systemInstruction, req);

    if (attempt.ok) {
      const parsed = parseStructuredAiOutput(attempt.rawText, req.planDepartmentHint);
      if (parsed.reply) {
        return {
          ok: true,
          reply: parsed.reply,
          providerUsed: candidate.displayName,
          learnedRule: parsed.learnedRule,
          routeDepartment: parsed.routeDepartment,
          lockedPlan: parsed.lockedPlan,
        };
      }
    } else if (attempt.shouldCooldown) {
      markKeyCooldown(candidate.keyId);
    }
  }

  return {
    ok: false,
    reply: '',
    noKeysConfigured: false,
  };
}

export const PREFERRED_NVIDIA_CODER_MODEL = 'qwen/qwen3-coder-480b-a35b-instruct';
const CODER_ATTEMPT_TIMEOUT_MS = 22_000;

export interface CoderAiRouterRequest {
  systemInstruction: string;
  userPrompt: string;
}

export interface CoderAiRouterResponse {
  ok: boolean;
  rawText: string;
  providerUsed?: string;
  noKeysConfigured?: boolean;
}

async function fetchWithCoderTimeout(url: string, init: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), CODER_ATTEMPT_TIMEOUT_MS);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timer);
  }
}

export async function runCoderAiRouter(
  req: CoderAiRouterRequest
): Promise<CoderAiRouterResponse> {
  const all = collectAllCandidates();
  if (all.length === 0) {
    return {
      ok: false,
      rawText: '',
      noKeysConfigured: true,
    };
  }

  const ready = all.filter((c) => !isKeyCooledDown(c.keyId));
  const pool = ready.length > 0 ? ready : all;

  // Prefer NVIDIA NIM with qwen/qwen3-coder-480b-a35b-instruct first, then fall back across Groq / Gemini / Cloudflare / OpenRouter
  const nvidiaCandidates = pool
    .filter((c) => c.group === 'nvidia')
    .map((c) => ({
      ...c,
      model: PREFERRED_NVIDIA_CODER_MODEL,
      displayName: `${c.displayName} (Qwen3 Coder 480B)`,
    }));

  const otherCandidates = pool.filter((c) => c.group !== 'nvidia');
  const ordered = [...nvidiaCandidates, ...otherCandidates];

  for (const candidate of ordered) {
    try {
      if (candidate.kind === 'gemini') {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${candidate.model}:generateContent?key=${encodeURIComponent(
          candidate.apiKey
        )}`;
        const res = await fetchWithCoderTimeout(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            systemInstruction: {
              parts: [{ text: req.systemInstruction }],
            },
            contents: [{ role: 'user', parts: [{ text: req.userPrompt }] }],
          }),
        });

        if (res.status === 429 || res.status === 503) {
          markKeyCooldown(candidate.keyId);
          continue;
        }
        if (!res.ok) continue;

        const data = (await res.json()) as {
          candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
        };
        const text =
          data.candidates?.[0]?.content?.parts
            ?.map((p) => p.text ?? '')
            .join('')
            .trim() ?? '';
        if (text) {
          return { ok: true, rawText: text, providerUsed: candidate.displayName };
        }
      } else {
        const endpoint = resolveOpenAiChatEndpoint(candidate.endpoint || '');
        if (!endpoint) continue;

        const res = await fetchWithCoderTimeout(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${candidate.apiKey}`,
          },
          body: JSON.stringify({
            model: candidate.model,
            messages: [
              { role: 'system', content: req.systemInstruction },
              { role: 'user', content: req.userPrompt },
            ],
          }),
        });

        if (res.status === 429 || res.status === 503) {
          markKeyCooldown(candidate.keyId);
          continue;
        }
        if (!res.ok) continue;

        const data = (await res.json()) as {
          choices?: Array<{ message?: { content?: string } }>;
        };
        const text = data.choices?.[0]?.message?.content?.trim() ?? '';
        if (text) {
          return { ok: true, rawText: text, providerUsed: candidate.displayName };
        }
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        markKeyCooldown(candidate.keyId);
      }
    }
  }

  return {
    ok: false,
    rawText: '',
    noKeysConfigured: false,
  };
}

const CREATIVE_ATTEMPT_TIMEOUT_MS = 18_000;

export interface CreativeAiRouterRequest {
  systemInstruction: string;
  userPrompt: string;
  expectJson?: boolean;
}

export interface CreativeAiRouterResponse {
  ok: boolean;
  rawText: string;
  providerUsed?: string;
  noKeysConfigured?: boolean;
}

async function fetchWithCreativeTimeout(url: string, init: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), CREATIVE_ATTEMPT_TIMEOUT_MS);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timer);
  }
}

export async function runCreativeAiRouter(
  req: CreativeAiRouterRequest
): Promise<CreativeAiRouterResponse> {
  const all = collectAllCandidates();
  if (all.length === 0) {
    return {
      ok: false,
      rawText: '',
      noKeysConfigured: true,
    };
  }

  const ordered = prioritizeCandidates(all, 'auto');

  for (const candidate of ordered) {
    try {
      if (candidate.kind === 'gemini') {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${candidate.model}:generateContent?key=${encodeURIComponent(
          candidate.apiKey
        )}`;
        const body: Record<string, unknown> = {
          systemInstruction: {
            parts: [{ text: req.systemInstruction }],
          },
          contents: [{ role: 'user', parts: [{ text: req.userPrompt }] }],
        };
        if (req.expectJson) {
          body.generationConfig = { responseMimeType: 'application/json' };
        }

        const res = await fetchWithCreativeTimeout(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });

        if (res.status === 429 || res.status === 503) {
          markKeyCooldown(candidate.keyId);
          continue;
        }
        if (!res.ok) continue;

        const data = (await res.json()) as {
          candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
        };
        const text =
          data.candidates?.[0]?.content?.parts
            ?.map((p) => p.text ?? '')
            .join('')
            .trim() ?? '';
        if (text) {
          return { ok: true, rawText: text, providerUsed: candidate.displayName };
        }
      } else {
        const endpoint = resolveOpenAiChatEndpoint(candidate.endpoint || '');
        if (!endpoint) continue;

        const res = await fetchWithCreativeTimeout(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${candidate.apiKey}`,
          },
          body: JSON.stringify({
            model: candidate.model,
            messages: [
              { role: 'system', content: req.systemInstruction },
              { role: 'user', content: req.userPrompt },
            ],
          }),
        });

        if (res.status === 429 || res.status === 503) {
          markKeyCooldown(candidate.keyId);
          continue;
        }
        if (!res.ok) continue;

        const data = (await res.json()) as {
          choices?: Array<{ message?: { content?: string } }>;
        };
        const text = data.choices?.[0]?.message?.content?.trim() ?? '';
        if (text) {
          return { ok: true, rawText: text, providerUsed: candidate.displayName };
        }
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        markKeyCooldown(candidate.keyId);
      }
    }
  }

  return {
    ok: false,
    rawText: '',
    noKeysConfigured: false,
  };
}
