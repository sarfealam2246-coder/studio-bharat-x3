import { DepartmentId, ProjectFile, StudioProject } from '../types/studio';
import { studioBus } from './eventBus';

const DB_NAME = 'studio_bharat_x_db';
const DB_VERSION = 1;
const STORE_NAME = 'projects';
const FALLBACK_KEY = 'studio_bharat_x_projects_fallback_v1';

type StorageBackend = 'indexeddb' | 'localstorage';

let activeBackend: StorageBackend = 'indexeddb';
let dbPromise: Promise<IDBDatabase | null> | null = null;

function generateId(prefix: string): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `${prefix}_${crypto.randomUUID().slice(0, 12)}`;
  }
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function readFallbackProjects(): StudioProject[] {
  try {
    const raw = window.localStorage.getItem(FALLBACK_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as StudioProject[]) : [];
  } catch {
    return [];
  }
}

function writeFallbackProjects(projects: StudioProject[]): void {
  try {
    window.localStorage.setItem(FALLBACK_KEY, JSON.stringify(projects));
  } catch {
    // Non-blocking fallback when storage is unavailable.
  }
}

function openDatabase(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    activeBackend = 'localstorage';
    return Promise.resolve(null);
  }
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve) => {
    try {
      const request = window.indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
          store.createIndex('by_department', 'department', { unique: false });
          store.createIndex('by_updatedAt', 'updatedAt', { unique: false });
        }
      };
      request.onsuccess = () => {
        activeBackend = 'indexeddb';
        resolve(request.result);
      };
      request.onerror = () => {
        activeBackend = 'localstorage';
        resolve(null);
      };
      request.onblocked = () => {
        activeBackend = 'localstorage';
        resolve(null);
      };
    } catch {
      activeBackend = 'localstorage';
      resolve(null);
    }
  });

  return dbPromise;
}

function createStarterFiles(department: DepartmentId, projectName: string): ProjectFile[] {
  const now = Date.now();
  switch (department) {
    case 'gaming':
      return [
        {
          id: generateId('file'),
          path: 'scene.config.json',
          language: 'json',
          updatedAt: now,
          content: JSON.stringify(
            {
              project: projectName,
              department: 'gaming',
              aspectRatio: '16:9',
              targetFps: 60,
              world: {
                title: projectName,
                gravity: 9.8,
                palette: ['#0A0B0E', '#F59E0B', '#F4F5F7'],
              },
            },
            null,
            2
          ),
        },
        {
          id: generateId('file'),
          path: 'design-notes.md',
          language: 'markdown',
          updatedAt: now,
          content: `# ${projectName}\n\n- Core loop: Define player controls and win condition.\n- Stage mode: Isolated Gaming preview ready for Part 4 engine.\n`,
        },
      ];
    case 'apps':
      return [
        {
          id: generateId('file'),
          path: 'app.manifest.json',
          language: 'json',
          updatedAt: now,
          content: JSON.stringify(
            {
              name: projectName,
              department: 'apps',
              viewport: 'mobile-first-360',
              screens: ['Home', 'Catalog', 'Checkout'],
            },
            null,
            2
          ),
        },
        {
          id: generateId('file'),
          path: 'routes.md',
          language: 'markdown',
          updatedAt: now,
          content: `# ${projectName}\n\n- Primary layout: Responsive mobile-first commercial shell.\n- Local persistence: Stored in studio_bharat_x_db.\n`,
        },
      ];
    case 'bhojpuri':
      return [
        {
          id: generateId('file'),
          path: 'reel.storyboard.md',
          language: 'markdown',
          updatedAt: now,
          content: `# ${projectName}\n\n- Format: 9:16 Vertical Reel\n- Hook (0-3s): Opening visual beat and Bhojpuri title card.\n- Scene 2 (3-15s): Chorus framing and caption sync.\n`,
        },
        {
          id: generateId('file'),
          path: 'reel.meta.json',
          language: 'json',
          updatedAt: now,
          content: JSON.stringify(
            {
              title: projectName,
              department: 'bhojpuri',
              aspectRatio: '9:16',
              durationSec: 30,
              language: 'bho-IN',
            },
            null,
            2
          ),
        },
      ];
    case 'agent':
      return [
        {
          id: generateId('file'),
          path: 'agent.workflow.json',
          language: 'json',
          updatedAt: now,
          content: JSON.stringify(
            {
              name: projectName,
              department: 'agent',
              trigger: 'manual',
              steps: [
                { id: 'step_1', action: 'inspect_screen', note: 'Capture current layout state' },
                { id: 'step_2', action: 'confirm_intent', note: 'Await user verification' },
              ],
            },
            null,
            2
          ),
        },
        {
          id: generateId('file'),
          path: 'checklist.md',
          language: 'markdown',
          updatedAt: now,
          content: `# ${projectName}\n\n- Safety guardrail: Explicit user confirmation before actions.\n- Isolated preview state kept separate from other rooms.\n`,
        },
      ];
  }
}

export function getStorageBackend(): StorageBackend {
  return activeBackend;
}

export async function listProjects(department?: DepartmentId): Promise<StudioProject[]> {
  const db = await openDatabase();
  let items: StudioProject[] = [];

  if (db) {
    items = await new Promise<StudioProject[]>((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const request = department
          ? store.index('by_department').getAll(department)
          : store.getAll();
        request.onsuccess = () => {
          resolve(Array.isArray(request.result) ? (request.result as StudioProject[]) : []);
        };
        request.onerror = () => resolve(readFallbackProjects());
      } catch {
        resolve(readFallbackProjects());
      }
    });
  } else {
    items = readFallbackProjects();
    if (department) {
      items = items.filter((p) => p.department === department);
    }
  }

  return items.sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function getProject(id: string): Promise<StudioProject | null> {
  const db = await openDatabase();
  if (db) {
    return new Promise<StudioProject | null>((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const request = tx.objectStore(STORE_NAME).get(id);
        request.onsuccess = () => resolve((request.result as StudioProject) ?? null);
        request.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
  }
  return readFallbackProjects().find((p) => p.id === id) ?? null;
}

export async function saveProject(project: StudioProject): Promise<StudioProject> {
  const updated: StudioProject = {
    ...project,
    updatedAt: Date.now(),
  };

  const db = await openDatabase();
  if (db) {
    await new Promise<void>((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).put(updated);
        tx.oncomplete = () => resolve();
        tx.onerror = () => {
          const current = readFallbackProjects().filter((p) => p.id !== updated.id);
          writeFallbackProjects([updated, ...current]);
          resolve();
        };
      } catch {
        const current = readFallbackProjects().filter((p) => p.id !== updated.id);
        writeFallbackProjects([updated, ...current]);
        resolve();
      }
    });
  } else {
    const current = readFallbackProjects().filter((p) => p.id !== updated.id);
    writeFallbackProjects([updated, ...current]);
  }

  studioBus.emit('project:saved', { project: updated });
  return updated;
}

export async function createProject(input: {
  name: string;
  department: DepartmentId;
  files?: ProjectFile[];
}): Promise<StudioProject> {
  const now = Date.now();
  const cleanName = input.name.trim() || `Untitled ${input.department} project`;
  const project: StudioProject = {
    id: generateId('proj'),
    name: cleanName,
    department: input.department,
    files: input.files && input.files.length > 0 ? input.files : createStarterFiles(input.department, cleanName),
    createdAt: now,
    updatedAt: now,
  };
  return saveProject(project);
}

export async function renameProject(id: string, nextName: string): Promise<StudioProject | null> {
  const existing = await getProject(id);
  if (!existing) return null;
  const trimmed = nextName.trim();
  if (!trimmed) return existing;
  return saveProject({
    ...existing,
    name: trimmed,
  });
}

export async function deleteProject(id: string, department: DepartmentId): Promise<void> {
  const db = await openDatabase();
  if (db) {
    await new Promise<void>((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).delete(id);
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch {
        resolve();
      }
    });
  }
  const fallback = readFallbackProjects();
  if (fallback.some((p) => p.id === id)) {
    writeFallbackProjects(fallback.filter((p) => p.id !== id));
  }
  studioBus.emit('project:deleted', { projectId: id, department });
}

export function createNewProjectFile(path: string, content = ''): ProjectFile {
  const cleanPath = path.trim() || `note-${Date.now().toString(36)}.md`;
  const ext = cleanPath.split('.').pop()?.toLowerCase() ?? 'txt';
  const languageMap: Record<string, string> = {
    json: 'json',
    md: 'markdown',
    ts: 'typescript',
    tsx: 'typescript',
    js: 'javascript',
    html: 'html',
    css: 'css',
  };
  return {
    id: generateId('file'),
    path: cleanPath,
    language: languageMap[ext] ?? 'text',
    content,
    updatedAt: Date.now(),
  };
}
