import { FacebookReelMetric, StoredBhojpuriReel } from '../types/studio';
import { loadSecretsVault } from './secretsService';

const GRAPH_BASE = 'https://graph.facebook.com/v21.0';
const FB_TIMEOUT_MS = 25_000;

export interface MonetizationSafetyReport {
  safe: boolean;
  checks: Array<{ label: string; passed: boolean; detail: string }>;
}

export function runMonetizationSafetyCheck(
  title: string,
  hashtags: string[],
  durationSec: number
): MonetizationSafetyReport {
  const cleanTitle = title.trim();
  const hasSpamWords = /\b(free money|click link in bio|guaranteed cash|18\+|nsfw|pirated)\b/i.test(
    `${cleanTitle} ${hashtags.join(' ')}`
  );
  const validDuration = durationSec >= 10 && durationSec <= 90;
  const reasonableTagCount = hashtags.length >= 1 && hashtags.length <= 10;

  const checks = [
    {
      label: '9:16 Reel Duration (10s–90s)',
      passed: validDuration,
      detail: `${Math.round(durationSec)}s`,
    },
    {
      label: 'Watermark-Free Original Content',
      passed: true,
      detail: 'Clean Studio render',
    },
    {
      label: 'Monetization-Safe Title & Hashtags',
      passed: Boolean(cleanTitle) && !hasSpamWords && reasonableTagCount,
      detail: hasSpamWords
        ? 'Remove restricted promotional keywords'
        : `${hashtags.length} tag(s)`,
    },
  ];

  return {
    safe: checks.every((c) => c.passed),
    checks,
  };
}

export function hasFacebookPageCredentials(): {
  configured: boolean;
  pageId: string;
  accessToken: string;
} {
  const tokens = loadSecretsVault().platformTokens;
  const pageId = tokens.facebookPageId.trim();
  const accessToken = tokens.facebookPageAccessToken.trim();
  return {
    configured: Boolean(pageId && accessToken),
    pageId,
    accessToken,
  };
}

async function fetchWithFbTimeout(url: string, init: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), FB_TIMEOUT_MS);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timer);
  }
}

export type FacebookPublishStep = 'start' | 'upload' | 'finish';

export interface FacebookPublishResult {
  ok: boolean;
  videoId?: string;
  permalinkUrl?: string;
  message: string;
  needsSecrets?: boolean;
}

/**
 * Official 3-Step Meta Graph API v21.0 Reels Publishing Flow:
 * 1. upload_phase=start -> returns video_id & rupload.facebook.com upload_url
 * 2. POST upload_url -> binary upload (local Blob) OR remote file_url (GitHub Release MP4)
 * 3. upload_phase=finish + video_state=PUBLISHED -> publishes Reel with Title + Hashtags
 */
export async function publishReelToFacebookPage(params: {
  reel: StoredBhojpuriReel;
  title: string;
  hashtags: string[];
  onStep?: (step: FacebookPublishStep, status: 'active' | 'done' | 'error') => void;
}): Promise<FacebookPublishResult> {
  const creds = hasFacebookPageCredentials();
  if (!creds.configured) {
    return {
      ok: false,
      needsSecrets: true,
      message:
        'Add Facebook Page ID and Facebook Page Access Token in 🔑 Secrets (Section C), or use 📲 1-Tap Share to Facebook.',
    };
  }

  const safety = runMonetizationSafetyCheck(params.title, params.hashtags, params.reel.durationSec);
  if (!safety.safe) {
    return {
      ok: false,
      message: 'Monetization-Safe preflight flagged an issue. Adjust title, hashtags, or duration before publishing.',
    };
  }

  if (!params.reel.blob && !params.reel.remoteUrl) {
    return {
      ok: false,
      message: 'No video file or cloud MP4 URL attached to this reel. Render a reel first.',
    };
  }

  const caption = `${params.title.trim()}\n\n${params.hashtags.join(' ')}`.trim();

  try {
    // STEP 1: upload_phase=start
    params.onStep?.('start', 'active');
    const startForm = new URLSearchParams({
      upload_phase: 'start',
      access_token: creds.accessToken,
    });
    const startRes = await fetchWithFbTimeout(
      `${GRAPH_BASE}/${encodeURIComponent(creds.pageId)}/video_reels`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: startForm.toString(),
      }
    );

    const startData = (await startRes.json().catch(() => ({}))) as {
      video_id?: string;
      upload_url?: string;
      error?: { message?: string };
    };

    if (!startRes.ok || !startData.video_id) {
      params.onStep?.('start', 'error');
      return {
        ok: false,
        message:
          startData.error?.message || `Meta Graph API start failed (HTTP ${startRes.status}).`,
      };
    }

    const videoId = startData.video_id;
    const uploadUrl =
      startData.upload_url || `https://rupload.facebook.com/video-upload/v21.0/${videoId}`;
    params.onStep?.('start', 'done');

    // STEP 2: rupload.facebook.com upload (binary Blob OR remote cloud MP4 URL)
    params.onStep?.('upload', 'active');
    let uploadRes: Response;
    if (params.reel.blob) {
      uploadRes = await fetchWithFbTimeout(uploadUrl, {
        method: 'POST',
        headers: {
          Authorization: `OAuth ${creds.accessToken}`,
          offset: '0',
          file_size: String(params.reel.blob.size),
          'Content-Type': 'application/octet-stream',
        },
        body: params.reel.blob,
      });
    } else {
      uploadRes = await fetchWithFbTimeout(uploadUrl, {
        method: 'POST',
        headers: {
          Authorization: `OAuth ${creds.accessToken}`,
          file_url: params.reel.remoteUrl!,
        },
      });
    }

    const uploadData = (await uploadRes.json().catch(() => ({}))) as {
      success?: boolean;
      error?: { message?: string };
    };
    if (!uploadRes.ok || uploadData.error) {
      params.onStep?.('upload', 'error');
      return {
        ok: false,
        message:
          uploadData.error?.message ||
          `Meta rupload transfer failed (HTTP ${uploadRes.status}).`,
      };
    }
    params.onStep?.('upload', 'done');

    // STEP 3: upload_phase=finish + video_state=PUBLISHED
    params.onStep?.('finish', 'active');
    const finishForm = new URLSearchParams({
      upload_phase: 'finish',
      video_id: videoId,
      video_state: 'PUBLISHED',
      description: caption,
      access_token: creds.accessToken,
    });
    const finishRes = await fetchWithFbTimeout(
      `${GRAPH_BASE}/${encodeURIComponent(creds.pageId)}/video_reels`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: finishForm.toString(),
      }
    );

    const finishData = (await finishRes.json().catch(() => ({}))) as {
      success?: boolean;
      post_id?: string;
      error?: { message?: string };
    };

    if (!finishRes.ok || finishData.error) {
      params.onStep?.('finish', 'error');
      return {
        ok: false,
        message:
          finishData.error?.message ||
          `Meta Reels publish finish failed (HTTP ${finishRes.status}).`,
      };
    }

    params.onStep?.('finish', 'done');
    const permalinkUrl = `https://www.facebook.com/reel/${videoId}`;
    return {
      ok: true,
      videoId,
      permalinkUrl,
      message: `Published to Facebook Page Reels (ID: ${videoId}) ✓`,
    };
  } catch (err) {
    return {
      ok: false,
      message:
        err instanceof Error
          ? `Facebook Graph API error: ${err.message}`
          : 'Network error publishing to Facebook Page.',
    };
  }
}

export async function fetchRecentFacebookReelMetrics(): Promise<{
  ok: boolean;
  metrics: FacebookReelMetric[];
  error?: string;
}> {
  const creds = hasFacebookPageCredentials();
  if (!creds.configured) {
    return { ok: false, metrics: [], error: 'Connect Facebook Page credentials in Secrets.' };
  }

  try {
    const fields = 'id,description,created_time,views,likes.summary(true),permalink_url';
    const url = `${GRAPH_BASE}/${encodeURIComponent(
      creds.pageId
    )}/video_reels?fields=${encodeURIComponent(fields)}&limit=6&access_token=${encodeURIComponent(
      creds.accessToken
    )}`;

    const res = await fetchWithFbTimeout(url, { method: 'GET' });
    const data = (await res.json().catch(() => ({}))) as {
      data?: Array<{
        id: string;
        description?: string;
        created_time?: string;
        views?: number;
        likes?: { summary?: { total_count?: number } };
        permalink_url?: string;
      }>;
      error?: { message?: string };
    };

    if (!res.ok || data.error) {
      return {
        ok: false,
        metrics: [],
        error: data.error?.message || `Graph API HTTP ${res.status}`,
      };
    }

    const metrics: FacebookReelMetric[] = (data.data ?? []).map((item) => ({
      id: item.id,
      description: item.description?.trim() || `Reel ${item.id}`,
      createdTime: item.created_time || '',
      views: typeof item.views === 'number' ? item.views : 0,
      likes: item.likes?.summary?.total_count ?? 0,
      permalinkUrl: item.permalink_url
        ? item.permalink_url.startsWith('http')
          ? item.permalink_url
          : `https://www.facebook.com${item.permalink_url}`
        : `https://www.facebook.com/reel/${item.id}`,
    }));

    return { ok: true, metrics };
  } catch (err) {
    return {
      ok: false,
      metrics: [],
      error: err instanceof Error ? err.message : 'Could not fetch Page Reel metrics.',
    };
  }
}

export async function shareReelToFacebookFallback(
  reel: StoredBhojpuriReel,
  title: string,
  hashtags: string[]
): Promise<{ ok: boolean; message: string }> {
  const caption = `${title.trim()}\n\n${hashtags.join(' ')}`.trim();

  // Copy caption & hashtags cleanly so user can paste straight into Facebook Reels
  try {
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      await navigator.clipboard.writeText(caption);
    }
  } catch {
    // Non-blocking
  }

  const ext = reel.mimeType.includes('mp4') ? 'mp4' : 'webm';
  const safeName = `${(title || 'bhojpuri-reel')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 36) || 'bhojpuri-reel'}.${ext}`;

  // Try native Web Share API with video file on mobile browsers
  if (reel.blob && typeof navigator.share === 'function') {
    try {
      const file = new File([reel.blob], safeName, { type: reel.mimeType || 'video/webm' });
      const canShareFiles =
        typeof navigator.canShare === 'function' ? navigator.canShare({ files: [file] }) : false;
      if (canShareFiles) {
        await navigator.share({
          title,
          text: caption,
          files: [file],
        });
        return {
          ok: true,
          message: 'Opened native Share Sheet for Facebook Reels (caption copied ✓).',
        };
      }
    } catch {
      // User cancelled or browser blocked file share -> fall through to direct file download
    }
  }

  // Reliable download fallback for both local Blob and cloud GitHub Release MP4
  if (reel.blob) {
    const url = URL.createObjectURL(reel.blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = safeName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
    return {
      ok: true,
      message: `Downloaded ${safeName} & copied Bhojpuri caption + hashtags ✓ Ready to upload on Facebook Reels.`,
    };
  }

  if (reel.remoteUrl) {
    const a = document.createElement('a');
    a.href = reel.remoteUrl;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.download = safeName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    return {
      ok: true,
      message: 'Opened cloud MP4 download & copied Bhojpuri caption + hashtags ✓',
    };
  }

  return {
    ok: false,
    message: 'Render or sync a reel first before sharing.',
  };
}
