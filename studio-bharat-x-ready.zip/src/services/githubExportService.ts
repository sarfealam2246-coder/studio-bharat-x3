import { SecretsVaultState, StudioProject } from '../types/studio';

export interface PreFlightStatus {
  geminiCount: number;
  otherAiCount: number;
  hasGithubPat: boolean;
  hasFacebookToken: boolean;
}

export interface GitHubPushResult {
  ok: boolean;
  message: string;
  repoUrl?: string;
  actionsUrl?: string;
  pagesUrl?: string;
}

export function computePreFlightStatus(vault: SecretsVaultState): PreFlightStatus {
  return {
    geminiCount: vault.geminiKeys.filter((k) => k.trim().length > 0).length,
    otherAiCount: vault.otherAiKeys.filter((k) => k.apiKey.trim().length > 0).length,
    hasGithubPat: vault.platformTokens.githubPat.trim().length > 0,
    hasFacebookToken: vault.platformTokens.facebookPageAccessToken.trim().length > 0,
  };
}

export function buildApkWorkflowYaml(appName: string): string {
  const safeName = appName.replace(/[^a-zA-Z0-9_-]/g, '-').toLowerCase() || 'studio-bharat-x';
  return `name: Build ${appName} APK

on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  build-apk:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Unzip Project If Present
        run: |
          if ls *.zip 1> /dev/null 2>&1; then unzip -o "*.zip"; fi

      - name: Setup Node.js 22
        uses: actions/setup-node@v4
        with:
          node-version: '22'

      - name: Setup Java 21
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '21'

      - name: Install & Build Web App
        run: |
          npm install --legacy-peer-deps
          npm run build

      - name: Setup Capacitor 8 Android
        run: |
          npm install --legacy-peer-deps @capacitor/core@8 @capacitor/cli@8 @capacitor/android@8 @capacitor-community/text-to-speech@8
          npx cap add android || true
          npx cap sync android

      - name: Add Android Permissions
        run: |
          MANIFEST="android/app/src/main/AndroidManifest.xml"
          grep -q "RECORD_AUDIO" "$MANIFEST" || sed -i 's/<application/<uses-permission android:name="android.permission.RECORD_AUDIO" \\/>\\n    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" \\/>\\n    <uses-permission android:name="android.permission.CAMERA" \\/>\\n    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" \\/>\\n    <application/' "$MANIFEST"

      - name: Build Debug APK
        run: |
          cd android
          chmod +x gradlew
          ./gradlew assembleDebug

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: ${safeName}-apk
          path: android/app/build/outputs/apk/debug/app-debug.apk
`;
}

export function buildPinLockedAdminHtml(appName: string, ownerPin: string, repoUrl: string): string {
  const safePin = ownerPin.trim() || '1234';
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${appName} — Owner Admin</title>
  <style>
    body { margin:0; font-family: system-ui, sans-serif; background:#0A0B0E; color:#F4F5F7; display:flex; align-items:center; justify-content:center; min-height:100vh; padding:16px; }
    .card { width:100%; max-width:380px; background:#141720; border:1px solid rgba(255,255,255,0.12); border-radius:20px; padding:20px; }
    input, button { width:100%; padding:10px 12px; border-radius:12px; border:1px solid rgba(255,255,255,0.15); margin-top:10px; box-sizing:border-box; }
    input { background:#0A0B0E; color:#fff; }
    button { background:#F59E0B; color:#0A0B0E; font-weight:700; cursor:pointer; border:none; }
    .hidden { display:none; }
    a { color:#38BDF8; }
  </style>
</head>
<body>
  <div class="card">
    <h2>${appName} Admin</h2>
    <div id="lockBox">
      <p>Enter Owner PIN to unlock controls:</p>
      <input id="pinInput" type="password" placeholder="Owner PIN" />
      <button onclick="unlock()">Unlock Admin</button>
    </div>
    <div id="adminBox" class="hidden">
      <p>Admin Unlocked ✓</p>
      <p><a href="${repoUrl}/actions" target="_blank">Open GitHub APK Builds ↗</a></p>
    </div>
  </div>
  <script>
    function unlock() {
      if (document.getElementById('pinInput').value === '${safePin}') {
        document.getElementById('lockBox').classList.add('hidden');
        document.getElementById('adminBox').classList.remove('hidden');
      } else {
        alert('Invalid PIN');
      }
    }
  </script>
</body>
</html>`;
}

export function buildDeterministicQrMatrix(text: string, size = 21): boolean[][] {
  const grid: boolean[][] = Array.from({ length: size }, () => Array(size).fill(false));
  const drawFinder = (ox: number, oy: number) => {
    for (let r = 0; r < 7; r++) {
      for (let c = 0; c < 7; c++) {
        const border = r === 0 || r === 6 || c === 0 || c === 6;
        const center = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        grid[oy + r][ox + c] = border || center;
      }
    }
  };
  drawFinder(0, 0);
  drawFinder(size - 7, 0);
  drawFinder(0, size - 7);

  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const inFinder =
        (r < 8 && c < 8) || (r < 8 && c >= size - 8) || (r >= size - 8 && c < 8);
      if (inFinder) continue;
      hash ^= (r * 31 + c * 17) & 0xff;
      hash = Math.imul(hash, 16777619);
      grid[r][c] = (hash & 1) === 1;
    }
  }
  return grid;
}

export async function pushProjectAndApkToGitHub(params: {
  githubPat: string;
  owner: string;
  repo: string;
  appName: string;
  ownerPin: string;
  project: StudioProject | null;
}): Promise<GitHubPushResult> {
  const token = params.githubPat.trim();
  if (!token) {
    return { ok: false, message: 'GitHub PAT missing in Secrets Vault.' };
  }
  const owner = params.owner.trim() || 'sarfealam2246-coder';
  const repo = params.repo.trim() || 'studio-bharat-x';
  const repoUrl = `https://github.com/${owner}/${repo}`;
  const pagesUrl = `https://${owner}.github.io/${repo}/admin.html`;

  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github+json',
    'Content-Type': 'application/json',
  };

  try {
    // 1. Get main branch HEAD commit
    const refRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/ref/heads/main`, {
      headers,
    });
    if (!refRes.ok) {
      return {
        ok: false,
        message: `GitHub repo ${owner}/${repo} unreachable (HTTP ${refRes.status}). Make sure the repo exists with a main branch.`,
      };
    }
    const refData = (await refRes.json()) as { object?: { sha?: string } };
    const headSha = refData.object?.sha;
    if (!headSha) {
      return { ok: false, message: 'Could not read main branch SHA.' };
    }

    const commitRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/commits/${headSha}`, {
      headers,
    });
    const commitData = (await commitRes.json()) as { tree?: { sha?: string } };
    const baseTreeSha = commitData.tree?.sha;

    const filesToPush: { path: string; content: string }[] = [
      { path: '.github/workflows/build-apk.yml', content: buildApkWorkflowYaml(params.appName) },
      { path: 'docs/admin.html', content: buildPinLockedAdminHtml(params.appName, params.ownerPin, repoUrl) },
    ];
    if (params.project) {
      for (const f of params.project.files) {
        filesToPush.push({ path: f.path.replace(/^\/+/, ''), content: f.content });
      }
    }

    const treeItems: { path: string; mode: string; type: string; sha: string }[] = [];
    for (const f of filesToPush) {
      const blobRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/blobs`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ content: f.content, encoding: 'utf-8' }),
      });
      if (!blobRes.ok) continue;
      const blobJson = (await blobRes.json()) as { sha?: string };
      if (blobJson.sha) {
        treeItems.push({ path: f.path, mode: '100644', type: 'blob', sha: blobJson.sha });
      }
    }

    const treeRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/trees`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ base_tree: baseTreeSha, tree: treeItems }),
    });
    const treeData = (await treeRes.json()) as { sha?: string };
    if (!treeData.sha) {
      return { ok: false, message: 'Failed to create GitHub commit tree.' };
    }

    const newCommitRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/commits`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        message: `Deploy ${params.appName} + APK workflow from STUDIO BHARAT X`,
        tree: treeData.sha,
        parents: [headSha],
      }),
    });
    const newCommitData = (await newCommitRes.json()) as { sha?: string };
    if (!newCommitData.sha) {
      return { ok: false, message: 'Failed to create commit.' };
    }

    const updateRes = await fetch(`https://api.github.com/repos/${owner}/${repo}/git/refs/heads/main`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ sha: newCommitData.sha }),
    });
    if (!updateRes.ok) {
      return { ok: false, message: `Failed to update main branch (HTTP ${updateRes.status}).` };
    }

    return {
      ok: true,
      message: `Pushed ${filesToPush.length} files in 1 atomic commit! APK build triggered.`,
      repoUrl,
      actionsUrl: `${repoUrl}/actions`,
      pagesUrl,
    };
  } catch (err) {
    return {
      ok: false,
      message: err instanceof Error ? err.message : 'GitHub push failed.',
    };
  }
}
