import {
  Language,
  ProjectCheckpoint,
  ProjectFile,
  RealAppIcon,
  RealGamingAsset,
  StudioProject,
} from '../types/studio';
import { runCoderAiRouter } from './aiRouter';
import {
  needsThreeJsLibrary,
  sanitizeForAndroidSandbox,
  THREE_CDN_SCRIPT,
} from './previewErrorSpy';
import {
  createNewProjectFile,
  createProject,
  saveProject,
} from './projectStoreService';

const CHECKPOINTS_STORAGE_KEY = 'studio_bharat_x_checkpoints_v1';
const MAX_CHECKPOINTS_PER_PROJECT = 12;

export type CoderDepartment = 'gaming' | 'apps';

export interface CoderBuildResult {
  ok: boolean;
  project: StudioProject;
  summary: string;
  providerUsed?: string;
  checkpoint?: ProjectCheckpoint;
  noKeysConfigured?: boolean;
}

function readAllCheckpoints(): Record<string, ProjectCheckpoint[]> {
  try {
    const raw = window.localStorage.getItem(CHECKPOINTS_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object'
      ? (parsed as Record<string, ProjectCheckpoint[]>)
      : {};
  } catch {
    return {};
  }
}

function writeAllCheckpoints(map: Record<string, ProjectCheckpoint[]>): void {
  try {
    window.localStorage.setItem(CHECKPOINTS_STORAGE_KEY, JSON.stringify(map));
  } catch {
    // Non-blocking storage fallback.
  }
}

export function listProjectCheckpoints(projectId: string): ProjectCheckpoint[] {
  return readAllCheckpoints()[projectId] ?? [];
}

export function saveProjectCheckpoint(
  project: StudioProject,
  stepNumber: number,
  label: string
): ProjectCheckpoint {
  const checkpoint: ProjectCheckpoint = {
    id: `chk_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    projectId: project.id,
    label: label.slice(0, 60),
    stepNumber,
    createdAt: Date.now(),
    files: project.files.map((f) => ({ ...f })),
  };

  const all = readAllCheckpoints();
  const existing = all[project.id] ?? [];
  all[project.id] = [checkpoint, ...existing].slice(0, MAX_CHECKPOINTS_PER_PROJECT);
  writeAllCheckpoints(all);
  return checkpoint;
}

export async function restoreProjectCheckpoint(
  project: StudioProject,
  checkpointId: string
): Promise<StudioProject | null> {
  const checkpoints = listProjectCheckpoints(project.id);
  const target = checkpoints.find((c) => c.id === checkpointId);
  if (!target) return null;

  return saveProject({
    ...project,
    files: target.files.map((f) => ({ ...f, updatedAt: Date.now() })),
  });
}

function parseJsonOrHtmlFiles(
  rawText: string
): {
  summary: string;
  files: Partial<Record<'index.html' | 'styles.css' | 'app.js', string>>;
} | null {
  const trimmed = rawText.trim();
  if (!trimmed) return null;

  // 1. Try direct or fenced JSON object: { summary, files: { "index.html": ..., "styles.css": ..., "app.js": ... } }
  const jsonCandidates: string[] = [];
  const fencedJson = trimmed.match(/```json\s*([\s\S]*?)```/i);
  if (fencedJson?.[1]) jsonCandidates.push(fencedJson[1].trim());
  jsonCandidates.push(trimmed.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim());
  const firstBrace = trimmed.indexOf('{');
  const lastBrace = trimmed.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    jsonCandidates.push(trimmed.slice(firstBrace, lastBrace + 1));
  }

  for (const candidate of jsonCandidates) {
    try {
      const parsed = JSON.parse(candidate) as {
        summary?: unknown;
        files?: Record<string, unknown>;
        'index.html'?: unknown;
        'styles.css'?: unknown;
        'app.js'?: unknown;
      };
      const fileBag =
        parsed.files && typeof parsed.files === 'object' ? parsed.files : parsed;
      const html = typeof fileBag['index.html'] === 'string' ? fileBag['index.html'] : undefined;
      const css = typeof fileBag['styles.css'] === 'string' ? fileBag['styles.css'] : undefined;
      const js = typeof fileBag['app.js'] === 'string' ? fileBag['app.js'] : undefined;

      if (html || css || js) {
        return {
          summary:
            typeof parsed.summary === 'string' && parsed.summary.trim()
              ? parsed.summary.trim()
              : 'Updated project files cleanly.',
          files: {
            ...(html !== undefined ? { 'index.html': html } : {}),
            ...(css !== undefined ? { 'styles.css': css } : {}),
            ...(js !== undefined ? { 'app.js': js } : {}),
          },
        };
      }
    } catch {
      // Fall through to HTML/fenced fallback parser.
    }
  }

  // 2. Fallback parser for raw <!doctype html> or separate fenced html/css/js blocks
  const htmlBlock =
    trimmed.match(/```html\s*([\s\S]*?)```/i)?.[1]?.trim() ??
    (trimmed.match(/(<!doctype\s+html[\s\S]*<\/html>|<html[\s\S]*<\/html>)/i)?.[1]?.trim() ||
      undefined);
  const cssBlock = trimmed.match(/```css\s*([\s\S]*?)```/i)?.[1]?.trim();
  const jsBlock = trimmed.match(/```(?:js|javascript)\s*([\s\S]*?)```/i)?.[1]?.trim();

  if (htmlBlock || cssBlock || jsBlock) {
    return {
      summary: 'Built multi-file bundle from HTML/code response.',
      files: {
        ...(htmlBlock ? { 'index.html': htmlBlock } : {}),
        ...(cssBlock ? { 'styles.css': cssBlock } : {}),
        ...(jsBlock ? { 'app.js': jsBlock } : {}),
      },
    };
  }

  return null;
}

function ensureThreeScriptInHtml(html: string, js: string, department: CoderDepartment): string {
  const safeHtml = sanitizeForAndroidSandbox(html);
  if (!needsThreeJsLibrary(safeHtml, js, department)) return safeHtml;
  if (safeHtml.includes('three.min.js')) return safeHtml;

  const tag = `<script src="${THREE_CDN_SCRIPT}"></script>`;
  if (/<\/head>/i.test(safeHtml)) {
    return safeHtml.replace(/<\/head>/i, `  ${tag}\n</head>`);
  }
  return `${tag}\n${safeHtml}`;
}

function mergeCoderFiles(
  existingFiles: ProjectFile[],
  updates: Partial<Record<'index.html' | 'styles.css' | 'app.js', string>>,
  department: CoderDepartment
): ProjectFile[] {
  const now = Date.now();
  const sanitizedJs = updates['app.js'] !== undefined ? sanitizeForAndroidSandbox(updates['app.js']) : undefined;
  const sanitizedHtml =
    updates['index.html'] !== undefined
      ? ensureThreeScriptInHtml(
          updates['index.html'],
          sanitizedJs ?? existingFiles.find((f) => f.path === 'app.js')?.content ?? '',
          department
        )
      : undefined;

  const targetEntries: Array<{ path: 'index.html' | 'styles.css' | 'app.js'; content?: string }> = [
    { path: 'index.html', content: sanitizedHtml },
    { path: 'styles.css', content: updates['styles.css'] },
    { path: 'app.js', content: sanitizedJs },
  ];

  const nextFiles = existingFiles.map((f) => ({ ...f }));

  for (const entry of targetEntries) {
    if (entry.content === undefined) continue;
    const idx = nextFiles.findIndex((f) => f.path.toLowerCase() === entry.path);
    if (idx !== -1) {
      nextFiles[idx] = {
        ...nextFiles[idx],
        content: entry.content,
        updatedAt: now,
      };
    } else {
      nextFiles.unshift(createNewProjectFile(entry.path, entry.content));
    }
  }

  // Keep index.html, styles.css, app.js ordered cleanly at the front of file tabs
  const priority: Record<string, number> = {
    'index.html': 0,
    'styles.css': 1,
    'app.js': 2,
  };
  return nextFiles.sort((a, b) => {
    const pa = priority[a.path.toLowerCase()] ?? 10;
    const pb = priority[b.path.toLowerCase()] ?? 10;
    return pa - pb;
  });
}

function buildCoderSystemInstruction(department: CoderDepartment, language: Language): string {
  const deptRule =
    department === 'gaming'
      ? `You are building a playable, responsive, high-craft HTML5 / Canvas / Three.js game inside an isolated 360px-safe iframe.
- For ANY 3D game, ALWAYS load classic Three.js via <script src="${THREE_CDN_SCRIPT}"></script> in index.html and use global window.THREE (NEVER use <script type="importmap">, NEVER use esm.sh, NEVER use ES module import statements).
- Ensure touch controls + keyboard controls work smoothly on 360px mobile and desktop, with visible HUD and non-zero responsive canvas sizing.`
      : `You are building a real, commercial-grade, mobile-first (360px zero-overflow) interactive web application inside an isolated iframe.
- Build clean, functional UI with real interactive handlers, state persistence, crisp dark/light studio aesthetics, and responsive layouts.
- NEVER use <script type="importmap"> or esm.sh.`;

  return `You are STUDIO BHARAT X Multi-File AI Coder (${department.toUpperCase()} department).
${deptRule}

STRICT INCREMENTAL MULTI-FILE RULES:
- Preserve and evolve existing working code across Step 1 -> Step 2 -> Step N; NEVER erase previous features unless asked.
- Update or create exactly three core runtime files: "index.html", "styles.css", and "app.js".
- Keep HTML clean without broken external scripts. Inline/reference kept asset URLs or Iconify SVG URLs when provided.
- Return ONLY a valid JSON object (no extra prose outside JSON) with this exact shape:
{
  "summary": "Brief ${language === 'hi' ? 'Hindi or Hinglish' : 'English'} summary of what was built or fixed",
  "files": {
    "index.html": "Complete valid HTML5 document",
    "styles.css": "Complete CSS styles",
    "app.js": "Complete vanilla JS (classic script, no ES module import statements)"
  }
}`;
}

export async function runStudioCoderBuild(params: {
  department: CoderDepartment;
  project: StudioProject | null;
  prompt: string;
  stepNumber: number;
  language: Language;
  fixErrorContext?: string;
}): Promise<CoderBuildResult> {
  const { department, prompt, stepNumber, language, fixErrorContext } = params;

  // Ensure a real IndexedDB project exists for this department
  let activeProject = params.project;
  if (!activeProject) {
    const cleanTitle =
      prompt
        .replace(/[^\w\s\u0900-\u097F-]/g, '')
        .trim()
        .slice(0, 40) || (department === 'gaming' ? 'Gaming Project' : 'Commercial App');
    activeProject = await createProject({
      name: cleanTitle,
      department,
      files: [
        createNewProjectFile(
          'index.html',
          `<!doctype html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>${cleanTitle}</title>\n</head>\n<body>\n  <div id="app"></div>\n</body>\n</html>`
        ),
        createNewProjectFile('styles.css', 'html, body { margin: 0; padding: 0; background: #0a0b0e; color: #f4f5f7; font-family: system-ui, sans-serif; }'),
        createNewProjectFile('app.js', '// Ready for build step\n'),
      ],
    });
  }

  // Save 1-tap Checkpoint BEFORE applying this build/fix step
  const checkpoint = saveProjectCheckpoint(
    activeProject,
    stepNumber,
    fixErrorContext ? `Before Auto-Fix (Step ${stepNumber})` : `Before Step ${stepNumber}: ${prompt}`
  );

  const existingHtml = activeProject.files.find((f) => f.path.toLowerCase() === 'index.html')?.content ?? '';
  const existingCss = activeProject.files.find((f) => f.path.toLowerCase() === 'styles.css')?.content ?? '';
  const existingJs = activeProject.files.find((f) => f.path.toLowerCase() === 'app.js')?.content ?? '';
  const keptAssetsFile = activeProject.files.find((f) => f.path === 'assets.json')?.content;
  const keptIconsFile = activeProject.files.find((f) => f.path === 'icons.json')?.content;
  const lockedPlanFile = activeProject.files.find((f) => f.path === 'locked-plan.md')?.content;

  const userPromptSections = [
    `PROJECT NAME: ${activeProject.name}`,
    `DEPARTMENT: ${department}`,
    `BUILD STEP: Step ${stepNumber}`,
    `USER REQUEST: ${prompt}`,
    fixErrorContext
      ? `RUNTIME / PREVIEW ERRORS TO FIX IMMEDIATELY:\n${fixErrorContext}\nFix every error cleanly so the preview renders visibly with zero runtime, WebGL, or blank-canvas errors.`
      : '',
    lockedPlanFile ? `LOCKED STEP PLAN (locked-plan.md):\n${lockedPlanFile.slice(0, 1800)}` : '',
    keptAssetsFile ? `KEPT REAL ASSETS (assets.json — use these exact URLs where relevant):\n${keptAssetsFile.slice(0, 1600)}` : '',
    keptIconsFile ? `KEPT ICONIFY ICONS (icons.json — use these exact SVG URLs where relevant):\n${keptIconsFile.slice(0, 1200)}` : '',
    `CURRENT index.html:\n${existingHtml.slice(0, 5000)}`,
    `CURRENT styles.css:\n${existingCss.slice(0, 4000)}`,
    `CURRENT app.js:\n${existingJs.slice(0, 7000)}`,
  ].filter(Boolean);

  const aiRes = await runCoderAiRouter({
    systemInstruction: buildCoderSystemInstruction(department, language),
    userPrompt: userPromptSections.join('\n\n'),
  });

  if (!aiRes.ok) {
    return {
      ok: false,
      project: activeProject,
      checkpoint,
      noKeysConfigured: aiRes.noKeysConfigured,
      summary: aiRes.noKeysConfigured
        ? language === 'hi'
          ? 'AI Coder चलाने के लिए 🔑 Secrets में NVIDIA NIM, Gemini, Groq या OpenRouter की कोई भी कुंजी जोड़ें।'
          : 'Add any NVIDIA NIM, Gemini, Groq, or OpenRouter key in 🔑 Secrets to run the AI Coder.'
        : language === 'hi'
          ? 'अभी सभी AI Coder कुंजियाँ व्यस्त हैं। कृपया कुछ सेकंड बाद पुनः प्रयास करें।'
          : 'All configured AI Coder providers are busy or timed out. Please retry shortly.',
    };
  }

  const parsed = parseJsonOrHtmlFiles(aiRes.rawText);
  if (!parsed) {
    return {
      ok: false,
      project: activeProject,
      checkpoint,
      providerUsed: aiRes.providerUsed,
      summary:
        language === 'hi'
          ? 'कोड आउटपुट पार्स नहीं हो सका — पिछला चेकपॉइंट सुरक्षित है। पुनः प्रयास करें।'
          : 'Could not parse generated code files — your previous checkpoint is preserved. Please retry.',
    };
  }

  const mergedFiles = mergeCoderFiles(activeProject.files, parsed.files, department);
  const savedProject = await saveProject({
    ...activeProject,
    files: mergedFiles,
  });

  return {
    ok: true,
    project: savedProject,
    summary: parsed.summary,
    providerUsed: aiRes.providerUsed,
    checkpoint,
  };
}

export async function saveKeptGamingAssetToProject(
  project: StudioProject,
  asset: RealGamingAsset
): Promise<StudioProject> {
  const existingFile = project.files.find((f) => f.path === 'assets.json');
  let list: RealGamingAsset[] = [];
  if (existingFile) {
    try {
      const parsed = JSON.parse(existingFile.content);
      if (Array.isArray(parsed)) list = parsed as RealGamingAsset[];
    } catch {
      list = [];
    }
  }

  if (!list.some((item) => item.id === asset.id)) {
    list = [asset, ...list];
  }

  const jsonContent = JSON.stringify(list, null, 2);
  const nextFiles = existingFile
    ? project.files.map((f) =>
        f.id === existingFile.id ? { ...f, content: jsonContent, updatedAt: Date.now() } : f
      )
    : [...project.files, createNewProjectFile('assets.json', jsonContent)];

  return saveProject({
    ...project,
    files: nextFiles,
  });
}

export async function saveKeptAppIconToProject(
  project: StudioProject,
  icon: RealAppIcon
): Promise<StudioProject> {
  const existingFile = project.files.find((f) => f.path === 'icons.json');
  let list: RealAppIcon[] = [];
  if (existingFile) {
    try {
      const parsed = JSON.parse(existingFile.content);
      if (Array.isArray(parsed)) list = parsed as RealAppIcon[];
    } catch {
      list = [];
    }
  }

  if (!list.some((item) => item.id === icon.id)) {
    list = [icon, ...list];
  }

  const jsonContent = JSON.stringify(list, null, 2);
  const nextFiles = existingFile
    ? project.files.map((f) =>
        f.id === existingFile.id ? { ...f, content: jsonContent, updatedAt: Date.now() } : f
      )
    : [...project.files, createNewProjectFile('icons.json', jsonContent)];

  return saveProject({
    ...project,
    files: nextFiles,
  });
}
