import {
  BhojpuriCharacterSlot,
  BhojpuriPipelineStepId,
  BhojpuriPipelineStepStatus,
  BhojpuriScene,
  BhojpuriScheduleFrequency,
  BhojpuriScheduleState,
  BhojpuriStoryPlan,
  Language,
  ProjectFile,
  ResearchSource,
  StudioProject,
  VoicePersona,
} from '../types/studio';
import { runCreativeAiRouter } from './aiRouter';
import { studioBus } from './eventBus';
import { runLiveWebResearch } from './liveWebResearchService';
import {
  createNewProjectFile,
  createProject,
  saveProject,
} from './projectStoreService';
import { loadSecretsVault } from './secretsService';

export const BHOJPURI_CHARS_STORAGE_KEY = 'studio_bharat_x_chars_v1';
export const BHOJPURI_STORY_STORAGE_KEY = 'studio_bharat_x_bhojpuri_story_v1';
export const BHOJPURI_SCHEDULE_STORAGE_KEY = 'studio_bharat_x_bhojpuri_schedule_v1';
export const GOOGLE_FLOW_URL = 'https://flow.google.com/';

const GEMINI_VISION_MODEL = 'gemini-4-hydrogen';
const GEMINI_IMAGE_MODEL = 'gemini-3.1-flash-lite-image';
const CLOUDFLARE_FLUX_MODEL = '@cf/black-forest-labs/flux-1-schnell';

const VISION_TIMEOUT_MS = 14_000;
const IMAGE_TIMEOUT_MS = 22_000;
const MEDIA_KEY_COOLDOWN_MS = 45_000;

const SIX_HOURS_MS = 6 * 60 * 60 * 1000;
const ONE_DAY_MS = 24 * 60 * 60 * 1000;

const VALID_VOICES: VoicePersona[] = ['Aoede', 'Puck', 'Charon', 'Kore'];

const TRENDING_QUERY_SEEDS = [
  'India viral comedy trends Bihar Bhojpuri street food monsoon',
  'India trending daily life humor electricity bill cricket chai stall',
  'Bihar Uttar Pradesh wedding festival funny culture trends India',
  'India trending smartphone UPI uncle neighbor comedy viral',
];

let geminiMediaCursor = 0;
const geminiMediaCooldown = new Map<number, number>();

export function createDefaultCharacterVault(): BhojpuriCharacterSlot[] {
  const now = Date.now();
  return [
    {
      slot: 1,
      enabled: true,
      name: 'Chintu',
      roleTag: 'Foodie Hero',
      voicePersona: 'Puck',
      photoDataUrl: null,
      dnaDescription:
        'Plump, energetic 3D Pixar-style Indian man in a bright saffron-orange cotton kurta, red checkered gamchha draped on shoulder, round expressive eyes, thick curved black mustache, big cheerful grin.',
      dnaLocked: true,
      dnaSource: 'default',
      updatedAt: now,
    },
    {
      slot: 2,
      enabled: true,
      name: 'Pintu',
      roleTag: 'Clever Sidekick',
      voicePersona: 'Charon',
      photoDataUrl: null,
      dnaDescription:
        'Tall, lanky 3D Pixar-style Indian young man wearing a royal-blue Nehru vest over a crisp white shirt, round black eyeglasses, messy spiky dark hair, mischievous raised eyebrows.',
      dnaLocked: true,
      dnaSource: 'default',
      updatedAt: now,
    },
    {
      slot: 3,
      enabled: true,
      name: 'Bhabhi Ji',
      roleTag: 'Sharp-Witted Neighbor',
      voicePersona: 'Aoede',
      photoDataUrl: null,
      dnaDescription:
        'Expressive 3D Pixar-style Indian woman in a vibrant crimson-and-gold festive saree, traditional gold jhumka earrings, neat braided hair with red bindi, dramatic witty expression.',
      dnaLocked: true,
      dnaSource: 'default',
      updatedAt: now,
    },
    {
      slot: 4,
      enabled: false,
      name: 'Chacha Ji',
      roleTag: 'Strict Village Elder',
      voicePersona: 'Kore',
      photoDataUrl: null,
      dnaDescription:
        'Sturdy 3D Pixar-style Indian elder in a spotless white kurta-dhoti, bold silver handlebar mustache, folded yellow scarf, bamboo walking stick, hilarious skeptical frown.',
      dnaLocked: true,
      dnaSource: 'default',
      updatedAt: now,
    },
  ];
}

export function loadCharacterVault(): BhojpuriCharacterSlot[] {
  const defaults = createDefaultCharacterVault();
  try {
    const raw = window.localStorage.getItem(BHOJPURI_CHARS_STORAGE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed) || parsed.length === 0) return defaults;

    return defaults.map((fallback) => {
      const match = parsed.find(
        (item): item is Partial<BhojpuriCharacterSlot> =>
          Boolean(item && typeof item === 'object' && (item as { slot?: number }).slot === fallback.slot)
      );
      if (!match) return fallback;
      const voice =
        typeof match.voicePersona === 'string' &&
        VALID_VOICES.includes(match.voicePersona as VoicePersona)
          ? (match.voicePersona as VoicePersona)
          : fallback.voicePersona;
      return {
        slot: fallback.slot,
        enabled: typeof match.enabled === 'boolean' ? match.enabled : fallback.enabled,
        name:
          typeof match.name === 'string' && match.name.trim()
            ? match.name.trim()
            : fallback.name,
        roleTag:
          typeof match.roleTag === 'string' && match.roleTag.trim()
            ? match.roleTag.trim()
            : fallback.roleTag,
        voicePersona: voice,
        photoDataUrl:
          typeof match.photoDataUrl === 'string' && match.photoDataUrl.startsWith('data:image/')
            ? match.photoDataUrl
            : null,
        dnaDescription:
          typeof match.dnaDescription === 'string' && match.dnaDescription.trim()
            ? match.dnaDescription.trim()
            : fallback.dnaDescription,
        dnaLocked: typeof match.dnaLocked === 'boolean' ? match.dnaLocked : true,
        dnaSource:
          match.dnaSource === 'vision' || match.dnaSource === 'manual' || match.dnaSource === 'default'
            ? match.dnaSource
            : 'default',
        updatedAt: typeof match.updatedAt === 'number' ? match.updatedAt : Date.now(),
      };
    });
  } catch {
    return defaults;
  }
}

export function saveCharacterVault(slots: BhojpuriCharacterSlot[]): BhojpuriCharacterSlot[] {
  try {
    window.localStorage.setItem(BHOJPURI_CHARS_STORAGE_KEY, JSON.stringify(slots));
  } catch {
    // If photo data URLs exceed storage quota, retry without photo payloads while preserving locked DNA.
    try {
      const compact = slots.map((s) => ({ ...s, photoDataUrl: null }));
      window.localStorage.setItem(BHOJPURI_CHARS_STORAGE_KEY, JSON.stringify(compact));
    } catch {
      // Non-blocking fallback.
    }
  }
  return slots;
}

export function loadBhojpuriSchedule(): BhojpuriScheduleState {
  const fallback: BhojpuriScheduleState = {
    frequency: 'off',
    lastAutoRunAt: 0,
    hasUnreadStory: false,
  };
  try {
    const raw = window.localStorage.getItem(BHOJPURI_SCHEDULE_STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<BhojpuriScheduleState>;
    const frequency: BhojpuriScheduleFrequency =
      parsed.frequency === '6h' || parsed.frequency === 'daily' || parsed.frequency === 'off'
        ? parsed.frequency
        : 'off';
    return {
      frequency,
      lastAutoRunAt: typeof parsed.lastAutoRunAt === 'number' ? parsed.lastAutoRunAt : 0,
      hasUnreadStory: Boolean(parsed.hasUnreadStory),
    };
  } catch {
    return fallback;
  }
}

export function saveBhojpuriSchedule(state: BhojpuriScheduleState): BhojpuriScheduleState {
  try {
    window.localStorage.setItem(BHOJPURI_SCHEDULE_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Non-blocking fallback.
  }
  return state;
}

export function isAutoScheduleDue(state: BhojpuriScheduleState): boolean {
  if (state.frequency === 'off') return false;
  const interval = state.frequency === '6h' ? SIX_HOURS_MS : ONE_DAY_MS;
  if (state.lastAutoRunAt <= 0) return true;
  return Date.now() - state.lastAutoRunAt >= interval;
}

export function markBhojpuriStoryRead(): BhojpuriScheduleState {
  const current = loadBhojpuriSchedule();
  if (!current.hasUnreadStory) return current;
  return saveBhojpuriSchedule({ ...current, hasUnreadStory: false });
}

export function loadSavedBhojpuriStory(): BhojpuriStoryPlan | null {
  try {
    const raw = window.localStorage.getItem(BHOJPURI_STORY_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<BhojpuriStoryPlan>;
    if (!parsed || !Array.isArray(parsed.scenes) || parsed.scenes.length === 0) return null;
    return parsed as BhojpuriStoryPlan;
  } catch {
    return null;
  }
}

export function saveBhojpuriStory(story: BhojpuriStoryPlan): void {
  try {
    window.localStorage.setItem(BHOJPURI_STORY_STORAGE_KEY, JSON.stringify(story));
  } catch {
    // Retry without large inline image data URLs so script & prompts always persist cleanly
    try {
      const stripped: BhojpuriStoryPlan = {
        ...story,
        thumbnailImageUrl: undefined,
        scenes: story.scenes.map((scene) => ({ ...scene, imageUrl: undefined })),
      };
      window.localStorage.setItem(BHOJPURI_STORY_STORAGE_KEY, JSON.stringify(stripped));
    } catch {
      // Non-blocking fallback.
    }
  }
}

function getOrderedGeminiMediaKeys(): Array<{ slotIndex: number; apiKey: string }> {
  const vault = loadSecretsVault();
  const configured: Array<{ slotIndex: number; apiKey: string }> = [];
  vault.geminiKeys.forEach((raw, idx) => {
    const trimmed = raw.trim();
    if (trimmed) {
      configured.push({ slotIndex: idx, apiKey: trimmed });
    }
  });
  if (configured.length === 0) return [];

  const offset = geminiMediaCursor % configured.length;
  geminiMediaCursor = (geminiMediaCursor + 1) % configured.length;
  const rotated = [...configured.slice(offset), ...configured.slice(0, offset)];

  const now = Date.now();
  const ready = rotated.filter((k) => now >= (geminiMediaCooldown.get(k.slotIndex) ?? 0));
  return ready.length > 0 ? ready : rotated;
}

export function compressCharacterPhoto(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read selected image file.'));
    reader.onload = () => {
      const src = typeof reader.result === 'string' ? reader.result : '';
      if (!src) {
        reject(new Error('Empty image data.'));
        return;
      }
      const img = new Image();
      img.onerror = () => resolve(src);
      img.onload = () => {
        const maxDim = 384;
        const scale = Math.min(1, maxDim / Math.max(img.width || 1, img.height || 1));
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(src);
          return;
        }
        ctx.drawImage(img, 0, 0, targetW, targetH);
        try {
          resolve(canvas.toDataURL('image/jpeg', 0.82));
        } catch {
          resolve(src);
        }
      };
      img.src = src;
    };
    reader.readAsDataURL(file);
  });
}

function splitDataUrl(dataUrl: string): { mimeType: string; base64: string } | null {
  const match = dataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!match) return null;
  return { mimeType: match[1], base64: match[2] };
}

export interface VisionDnaResult {
  ok: boolean;
  dna?: string;
  keySlot?: number;
  error?: string;
  noKeysConfigured?: boolean;
}

export async function extractCharacterDnaWithGeminiVision(
  photoDataUrl: string,
  characterName: string
): Promise<VisionDnaResult> {
  const parsed = splitDataUrl(photoDataUrl);
  if (!parsed) {
    return { ok: false, error: 'Unsupported photo format. Please upload PNG, JPG, or WebP.' };
  }

  const keys = getOrderedGeminiMediaKeys();
  if (keys.length === 0) {
    return {
      ok: false,
      noKeysConfigured: true,
      error: 'Add at least 1 Gemini Key in Secrets Vault to run Gemini Vision DNA Lock.',
    };
  }

  const prompt = `Analyze this character reference photo for "${characterName}" in a 3D Pixar-style Bhojpuri animated comedy series.
Write ONE concise, consistent Character DNA description (28–45 words max) covering:
- build/age look, hair/mustache/beard style, skin tone & signature expression
- exact outfit style, colors, patterns, and signature accessories (glasses, gamchha, jewelry, etc.)
Return ONLY the clean DNA description sentence — no markdown, no bullets, no intro text.`;

  for (const slot of keys) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), VISION_TIMEOUT_MS);
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_VISION_MODEL}:generateContent?key=${encodeURIComponent(
        slot.apiKey
      )}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    mimeType: parsed.mimeType,
                    data: parsed.base64,
                  },
                },
                { text: prompt },
              ],
            },
          ],
        }),
      });

      if (res.status === 429 || res.status === 503) {
        geminiMediaCooldown.set(slot.slotIndex, Date.now() + MEDIA_KEY_COOLDOWN_MS);
        continue;
      }
      if (!res.ok) continue;

      const data = (await res.json()) as {
        candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
      };
      const text =
        data.candidates?.[0]?.content?.parts
          ?.map((p) => p.text ?? '')
          .join(' ')
          .replace(/\s+/g, ' ')
          .trim() ?? '';

      if (text) {
        return {
          ok: true,
          dna: text.slice(0, 320),
          keySlot: slot.slotIndex + 1,
        };
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        geminiMediaCooldown.set(slot.slotIndex, Date.now() + MEDIA_KEY_COOLDOWN_MS);
      }
    } finally {
      window.clearTimeout(timer);
    }
  }

  return {
    ok: false,
    error: 'Gemini Vision keys are temporarily busy. Photo saved locally — you can retry or edit DNA manually.',
  };
}

export interface PipelineProgressCallback {
  (step: BhojpuriPipelineStepId, status: BhojpuriPipelineStepStatus, detail?: string): void;
}

export interface BhojpuriPipelineResult {
  ok: boolean;
  story?: BhojpuriStoryPlan;
  error?: string;
  noKeysConfigured?: boolean;
}

function buildCharacterBible(characters: BhojpuriCharacterSlot[]): string {
  const active = characters.filter((c) => c.enabled);
  return active
    .map(
      (c) =>
        `- ${c.name} (${c.roleTag}, Voice: ${c.voicePersona}, DNA Locked): ${c.dnaDescription}`
    )
    .join('\n');
}

function parseJsonObjectFromRaw(raw: string): Record<string, unknown> | null {
  const cleaned = raw
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();
  try {
    const parsed = JSON.parse(cleaned);
    if (parsed && typeof parsed === 'object') return parsed as Record<string, unknown>;
  } catch {
    // Fallback to outer braces extraction
  }
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start !== -1 && end > start) {
    try {
      const parsed = JSON.parse(cleaned.slice(start, end + 1));
      if (parsed && typeof parsed === 'object') return parsed as Record<string, unknown>;
    } catch {
      return null;
    }
  }
  return null;
}

function injectCharacterDnaIntoPrompt(
  basePrompt: string,
  speakerName: string,
  activeChars: BhojpuriCharacterSlot[]
): string {
  const lower = basePrompt.toLowerCase();
  const matched = activeChars.filter(
    (c) =>
      c.dnaLocked &&
      (c.name.toLowerCase() === speakerName.toLowerCase() ||
        lower.includes(c.name.toLowerCase()))
  );
  const charsToLock = matched.length > 0 ? matched : activeChars.slice(0, 2);
  const dnaSuffix = charsToLock
    .map((c) => `${c.name}: ${c.dnaDescription}`)
    .join(' | ');

  const hasPixar = /pixar|3d\s+cartoon|3d\s+animated/i.test(basePrompt);
  const stylePrefix = hasPixar
    ? ''
    : '3D Pixar-style stylized cartoon animation, vibrant Indian desi lighting, 9:16 vertical frame: ';

  const alreadyHasDna =
    charsToLock.length > 0 &&
    basePrompt.toLowerCase().includes(charsToLock[0].dnaDescription.slice(0, 24).toLowerCase());

  return `${stylePrefix}${basePrompt.trim()}${
    alreadyHasDna ? '' : ` [Locked Character DNA: ${dnaSuffix}]`
  }. Strictly watermark-free, no logos, no text overlay.`;
}

export async function runBhojpuriResearchAndStoryPipeline(params: {
  customTopic?: string;
  characters: BhojpuriCharacterSlot[];
  language: Language;
  onStepUpdate?: PipelineProgressCallback;
  markAsAutoScheduled?: boolean;
}): Promise<BhojpuriPipelineResult> {
  const { customTopic, characters, onStepUpdate, markAsAutoScheduled } = params;
  const activeChars = characters.filter((c) => c.enabled);
  const usableChars = activeChars.length >= 2 ? activeChars : characters.slice(0, 2);

  // Step 1: Trending Topics (real live web research)
  onStepUpdate?.('trending', 'active', 'Fetching live web trends...');
  const seedQuery =
    customTopic && customTopic.trim()
      ? `${customTopic.trim()} India viral comedy Bihar Bhojpuri`
      : TRENDING_QUERY_SEEDS[Math.floor(Date.now() / 60_000) % TRENDING_QUERY_SEEDS.length];

  let findings: ResearchSource[] = [];
  let contextBlock = '';
  try {
    const research = await runLiveWebResearch(seedQuery);
    findings = research.findings;
    contextBlock = research.contextBlock;
  } catch {
    // Live research is best-effort; continue cleanly into synthesis
  }
  onStepUpdate?.(
    'trending',
    'done',
    findings.length > 0 ? `${findings.length} live signals found` : 'Topic hook locked'
  );

  // Step 2: Desi Context
  onStepUpdate?.('desi_context', 'active', 'Mapping Purvanchal/Bihar desi setting...');
  const characterBible = buildCharacterBible(usableChars);
  const voiceMapHint = usableChars
    .map((c) => `"${c.name}" -> "${c.voicePersona}"`)
    .join(', ');

  // Brief natural visual transition so user sees each stage execute clearly
  await new Promise((r) => window.setTimeout(r, 180));
  onStepUpdate?.('desi_context', 'done', `${usableChars.length} locked characters cast`);

  // Step 3: Comedy Twist
  onStepUpdate?.('comedy_twist', 'active', 'Crafting Motu-Patlu escalation & punchline...');

  const systemInstruction = `You are a veteran Bhojpuri comedy showrunner creating viral 30-to-60-second vertical 9:16 3D Pixar-style cartoon reels (classic Motu-Patlu / desi mohalla slapstick & witty banter vibe).

STRICT CREATIVE RULES:
1. Write GENUINE, natural, hilarious Bhojpuri/Purvanchal-Hindi comedy — witty, warm, expressive, punchy everyday banter ("अरे भैया!", "का हो गइल!", "ई का बवाल कइलऽ!"). NEVER robotic filler, NEVER moral lectures, NEVER stiff literal translations.
2. Structure strictly across 6 to 8 scenes (total duration between 34 and 56 seconds):
   - Scenes 1-2: Relatable Desi Setup
   - Scenes 3-4: Funny Misunderstanding
   - Scenes 5-6: Chaotic Escalation
   - Final 1-2 Scenes: Hilarious Bhojpuri Punchline & comic reaction
3. Use ONLY these enabled cast members and strictly preserve their exact names and assigned voicePersona (${voiceMapHint}):
${characterBible}
4. Every scene's "visualPrompt" MUST be a vivid, watermark-free 3D Pixar-style cartoon shot in 9:16 vertical framing referencing the speaking character's Locked Character DNA (outfit, colors, mustache/hair, props) and expressive cartoon action.
5. Also generate a punchy "viralTitle" (Bhojpuri/Hinglish), 5-7 relevant "hashtags", and a striking "thumbnailPrompt" (9:16 expressive 3D Pixar-style cartoon thumbnail with ZERO watermarks/logos).

Return ONLY valid JSON with this exact schema:
{
  "topic": "Short comedy premise summary",
  "researchSummary": "1-sentence link from live trend/topic to this reel",
  "desiContextNote": "1-sentence desi mohalla/chai-stall/village setting",
  "comedyTwistNote": "1-sentence summary of the escalating twist & punchline",
  "viralTitle": "Viral Bhojpuri comedy title",
  "hashtags": ["#BhojpuriComedy", "#DesiCartoon", "#BhojpuriReels"],
  "thumbnailPrompt": "Vivid 9:16 3D Pixar cartoon thumbnail prompt with locked character appearances, expressive faces, no watermark",
  "scenes": [
    {
      "sceneNumber": 1,
      "durationSec": 6,
      "speaker": "${usableChars[0].name}",
      "voicePersona": "${usableChars[0].voicePersona}",
      "dialogue": "Natural punchy Bhojpuri dialogue line",
      "visualPrompt": "3D Pixar-style cartoon shot description with character DNA & camera angle",
      "sfxCue": "comic sound effect cue",
      "subtitle": "Short bold 9:16 caption line"
    }
  ]
}`;

  const userPrompt = [
    customTopic?.trim()
      ? `USER COMEDY TOPIC / IDEA: "${customTopic.trim()}"`
      : 'Pick a fresh, hilarious relatable everyday Bihar/UP/Bhojpuri comedy topic inspired by the live signals below.',
    contextBlock || 'Live context: Everyday Indian mohalla comedy — chai dukaan, samosa, bijli bill, wedding band, or smart-phone confusion.',
    'Generate a complete 6 to 8 scene (35s–55s) Motu-Patlu style Bhojpuri comedy script JSON now.',
  ].join('\n\n');

  onStepUpdate?.('scene_plan', 'active', 'Synthesizing 6–10 scenes & thumbnail plan...');

  const aiRes = await runCreativeAiRouter({
    systemInstruction,
    userPrompt,
    expectJson: true,
  });

  if (!aiRes.ok) {
    onStepUpdate?.('comedy_twist', 'error');
    onStepUpdate?.('scene_plan', 'error');
    return {
      ok: false,
      noKeysConfigured: aiRes.noKeysConfigured,
      error: aiRes.noKeysConfigured
        ? 'Add a Gemini, Groq, NVIDIA NIM, or OpenRouter key in Secrets Vault to run the Bhojpuri Story Pipeline.'
        : 'All configured AI providers are busy or timed out. Please retry in a moment.',
    };
  }

  onStepUpdate?.('comedy_twist', 'done', 'Twist locked');

  const obj = parseJsonObjectFromRaw(aiRes.rawText);
  if (!obj || !Array.isArray(obj.scenes) || obj.scenes.length === 0) {
    onStepUpdate?.('scene_plan', 'error');
    return {
      ok: false,
      error: 'The AI returned an incomplete script structure. Tap Research & Create Story to retry.',
    };
  }

  const rawScenes = obj.scenes.slice(0, 10);
  const normalizedScenes: BhojpuriScene[] = rawScenes.map((entry, idx) => {
    const item = entry as Record<string, unknown>;
    const rawSpeaker = typeof item.speaker === 'string' ? item.speaker.trim() : '';
    const matchedChar =
      usableChars.find((c) => c.name.toLowerCase() === rawSpeaker.toLowerCase()) ??
      usableChars[idx % usableChars.length];

    const voice: VoicePersona =
      typeof item.voicePersona === 'string' &&
      VALID_VOICES.includes(item.voicePersona as VoicePersona)
        ? matchedChar.voicePersona
        : matchedChar.voicePersona;

    const rawDur = typeof item.durationSec === 'number' ? Math.round(item.durationSec) : 6;
    const durationSec = Math.min(9, Math.max(4, rawDur));
    const dialogue =
      typeof item.dialogue === 'string' && item.dialogue.trim()
        ? item.dialogue.trim()
        : '...';
    const rawVisual =
      typeof item.visualPrompt === 'string' && item.visualPrompt.trim()
        ? item.visualPrompt.trim()
        : `${matchedChar.name} reacting comically in a colorful Indian mohalla street`;

    return {
      sceneNumber: idx + 1,
      durationSec,
      speaker: matchedChar.name,
      voicePersona: voice,
      dialogue,
      visualPrompt: injectCharacterDnaIntoPrompt(rawVisual, matchedChar.name, usableChars),
      sfxCue:
        typeof item.sfxCue === 'string' && item.sfxCue.trim()
          ? item.sfxCue.trim()
          : 'cartoon pop + desi dhol beat',
      subtitle:
        typeof item.subtitle === 'string' && item.subtitle.trim()
          ? item.subtitle.trim()
          : dialogue.slice(0, 72),
    };
  });

  const totalDurationSec = normalizedScenes.reduce((acc, s) => acc + s.durationSec, 0);
  const rawTags = Array.isArray(obj.hashtags)
    ? obj.hashtags
        .filter((h): h is string => typeof h === 'string' && Boolean(h.trim()))
        .map((h) => (h.startsWith('#') ? h.trim() : `#${h.trim().replace(/\s+/g, '')}`))
        .slice(0, 8)
    : ['#BhojpuriComedy', '#DesiCartoon', '#BhojpuriReels', '#MotuPatluVibe', '#StudioBharatX'];

  const rawThumb =
    typeof obj.thumbnailPrompt === 'string' && obj.thumbnailPrompt.trim()
      ? obj.thumbnailPrompt.trim()
      : `Hilarious shocked comic confrontation between ${usableChars
          .map((c) => c.name)
          .join(' and ')} at a vibrant Indian street chai stall`;

  const story: BhojpuriStoryPlan = {
    id: `bhj_${Date.now().toString(36)}`,
    topic:
      typeof obj.topic === 'string' && obj.topic.trim()
        ? obj.topic.trim()
        : customTopic?.trim() || 'Bhojpuri Mohalla Comedy',
    viralTitle:
      typeof obj.viralTitle === 'string' && obj.viralTitle.trim()
        ? obj.viralTitle.trim()
        : 'Chintu-Pintu Ka Bhojpuri Dhamaka',
    hashtags: rawTags,
    thumbnailPrompt: injectCharacterDnaIntoPrompt(rawThumb, usableChars[0].name, usableChars),
    totalDurationSec,
    researchSummary:
      typeof obj.researchSummary === 'string' && obj.researchSummary.trim()
        ? obj.researchSummary.trim()
        : findings[0]?.title
          ? `Inspired by live signal: ${findings[0].title}`
          : 'Synthesized from everyday desi Bhojpuri humor signals.',
    desiContextNote:
      typeof obj.desiContextNote === 'string' && obj.desiContextNote.trim()
        ? obj.desiContextNote.trim()
        : 'Bustling Purvanchal-Bihar mohalla setting with expressive cartoon props.',
    comedyTwistNote:
      typeof obj.comedyTwistNote === 'string' && obj.comedyTwistNote.trim()
        ? obj.comedyTwistNote.trim()
        : 'Classic escalating misunderstanding ending in a punchy Bhojpuri twist.',
    researchSources: findings.slice(0, 4),
    scenes: normalizedScenes,
    providerUsed: aiRes.providerUsed,
    createdAt: Date.now(),
  };

  saveBhojpuriStory(story);

  const currentSchedule = loadBhojpuriSchedule();
  saveBhojpuriSchedule({
    ...currentSchedule,
    lastAutoRunAt: markAsAutoScheduled ? Date.now() : currentSchedule.lastAutoRunAt || Date.now(),
    hasUnreadStory: true,
  });

  studioBus.emit('bhojpuri:storyReady', { storyId: story.id, title: story.viralTitle });
  onStepUpdate?.('scene_plan', 'done', `${normalizedScenes.length} scenes · ${totalDurationSec}s`);

  return { ok: true, story };
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return window.btoa(binary);
}

function resolveCloudflareFluxUrl(rawEndpoint: string): string | null {
  const clean = rawEndpoint.trim().replace(/\/+$/, '');
  if (!clean) return null;
  // Direct workers AI run endpoint or custom proxy
  if (clean.includes('/ai/run/')) {
    return clean.includes('flux')
      ? clean
      : `${clean.slice(0, clean.indexOf('/ai/run/'))}/ai/run/${CLOUDFLARE_FLUX_MODEL}`;
  }
  const acctMatch = clean.match(/accounts\/([a-zA-Z0-9_-]+)/);
  if (acctMatch) {
    return `https://api.cloudflare.com/client/v4/accounts/${acctMatch[1]}/ai/run/${CLOUDFLARE_FLUX_MODEL}`;
  }
  // Custom Cloudflare Worker proxy URL (non-verify endpoint)
  if (!clean.includes('/tokens/verify') && clean.startsWith('http')) {
    return clean;
  }
  return null;
}

async function tryCloudflareFluxImage(prompt: string): Promise<string | null> {
  const vault = loadSecretsVault();
  const cfEntries = vault.otherAiKeys.filter(
    (entry) => entry.provider === 'cloudflare_ai' && entry.apiKey.trim()
  );
  if (cfEntries.length === 0) return null;

  for (const entry of cfEntries) {
    const fluxUrl = resolveCloudflareFluxUrl(entry.endpoint);
    if (!fluxUrl) continue;

    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), IMAGE_TIMEOUT_MS);
    try {
      const res = await fetch(fluxUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${entry.apiKey.trim()}`,
          'Content-Type': 'application/json',
        },
        signal: controller.signal,
        body: JSON.stringify({
          prompt,
          num_steps: 4,
        }),
      });
      if (!res.ok) continue;

      const contentType = res.headers.get('content-type') || '';
      if (contentType.startsWith('image/')) {
        const buf = await res.arrayBuffer();
        const b64 = arrayBufferToBase64(buf);
        return `data:${contentType.split(';')[0]};base64,${b64}`;
      }

      const data = (await res.json()) as {
        result?: { image?: string };
        image?: string;
      };
      const base64Img = data.result?.image || data.image;
      if (base64Img) {
        return base64Img.startsWith('data:image/')
          ? base64Img
          : `data:image/jpeg;base64,${base64Img}`;
      }
    } catch {
      // Fail over cleanly to next Cloudflare entry or Gemini Image
    } finally {
      window.clearTimeout(timer);
    }
  }
  return null;
}

async function tryGeminiImage(
  prompt: string,
  aspectRatio: '9:16' | '1:1' = '9:16'
): Promise<{ imageUrl: string; provider: string } | null> {
  const keys = getOrderedGeminiMediaKeys();
  if (keys.length === 0) return null;

  for (const slot of keys) {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), IMAGE_TIMEOUT_MS);
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_IMAGE_MODEL}:generateContent?key=${encodeURIComponent(
        slot.apiKey
      )}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: prompt }],
            },
          ],
          generationConfig: {
            imageConfig: {
              aspectRatio,
            },
          },
        }),
      });

      if (res.status === 429 || res.status === 503) {
        geminiMediaCooldown.set(slot.slotIndex, Date.now() + MEDIA_KEY_COOLDOWN_MS);
        continue;
      }
      if (!res.ok) continue;

      const data = (await res.json()) as {
        candidates?: Array<{
          content?: {
            parts?: Array<{
              inlineData?: { data?: string; mimeType?: string };
            }>;
          };
        }>;
      };

      const parts = data.candidates?.[0]?.content?.parts ?? [];
      for (const part of parts) {
        if (part.inlineData?.data) {
          const mime = part.inlineData.mimeType || 'image/png';
          return {
            imageUrl: `data:${mime};base64,${part.inlineData.data}`,
            provider: `Gemini Image (Key ${slot.slotIndex + 1})`,
          };
        }
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        geminiMediaCooldown.set(slot.slotIndex, Date.now() + MEDIA_KEY_COOLDOWN_MS);
      }
    } finally {
      window.clearTimeout(timer);
    }
  }
  return null;
}

export interface ArtworkGenerationResult {
  ok: boolean;
  imageUrl?: string;
  provider?: string;
  noKeysConfigured?: boolean;
  error?: string;
}

export async function generateBhojpuriArtwork(
  visualPrompt: string,
  aspectRatio: '9:16' | '1:1' = '9:16'
): Promise<ArtworkGenerationResult> {
  const vault = loadSecretsVault();
  const hasGemini = vault.geminiKeys.some((k) => Boolean(k.trim()));
  const hasCf = vault.otherAiKeys.some(
    (entry) => entry.provider === 'cloudflare_ai' && Boolean(entry.apiKey.trim())
  );

  if (!hasGemini && !hasCf) {
    return {
      ok: false,
      noKeysConfigured: true,
      error:
        'Configure a Cloudflare AI Flux key or Gemini API key in Secrets Vault to render 3D scenes & thumbnails.',
    };
  }

  const safePrompt = `${visualPrompt.trim()} High-craft 3D Pixar-style animated cartoon frame, bright warm lighting, expressive characters, strictly no watermark, no text, no signature.`;

  // 1. Prefer Cloudflare Flux (@cf/black-forest-labs/flux-1-schnell) when configured with an account/worker URL
  const cfUrl = await tryCloudflareFluxImage(safePrompt);
  if (cfUrl) {
    return { ok: true, imageUrl: cfUrl, provider: 'Cloudflare Flux Schnell' };
  }

  // 2. Fail over cleanly to 3-key Gemini Image pool
  const geminiRes = await tryGeminiImage(safePrompt, aspectRatio);
  if (geminiRes) {
    return { ok: true, imageUrl: geminiRes.imageUrl, provider: geminiRes.provider };
  }

  return {
    ok: false,
    error:
      'Image generation keys were busy or rejected the request. Check Cloudflare Flux endpoint or Gemini Image billing/quota in Secrets.',
  };
}

export function formatGoogleFlowPrompt(
  story: BhojpuriStoryPlan,
  characters: BhojpuriCharacterSlot[]
): string {
  const enabledChars = characters.filter((c) => c.enabled);
  const dnaLines = enabledChars
    .map(
      (c) =>
        `• ${c.name} (${c.roleTag} | Voice: ${c.voicePersona}): ${c.dnaDescription}`
    )
    .join('\n');

  const sceneLines = story.scenes
    .map(
      (scene) =>
        `SCENE ${scene.sceneNumber} (${scene.durationSec}s) — ${scene.speaker} [${scene.voicePersona}]\n` +
        `Visual: ${scene.visualPrompt}\n` +
        `Bhojpuri Dialogue: "${scene.dialogue}"\n` +
        `SFX: ${scene.sfxCue}\n` +
        `Subtitle: ${scene.subtitle}`
    )
    .join('\n\n');

  return [
    `=== STUDIO BHARAT X — GOOGLE FLOW / VEO 9:16 PACK ===`,
    `TITLE: ${story.viralTitle}`,
    `FORMAT: 9:16 Vertical 3D Pixar-Style Cartoon Comedy (${story.totalDurationSec}s) | STRICTLY WATERMARK-FREE`,
    `HASHTAGS: ${story.hashtags.join(' ')}`,
    ``,
    `--- LOCKED CHARACTER DNA BIBLE ---`,
    dnaLines,
    ``,
    `--- 9:16 THUMBNAIL PROMPT ---`,
    story.thumbnailPrompt,
    ``,
    `--- SCENE-BY-SCENE VIDEO PROMPTS ---`,
    sceneLines,
  ].join('\n');
}

function upsertProjectFile(
  files: ProjectFile[],
  path: string,
  content: string
): ProjectFile[] {
  const existing = files.find((f) => f.path === path);
  if (existing) {
    return files.map((f) =>
      f.id === existing.id ? { ...f, content, updatedAt: Date.now() } : f
    );
  }
  return [...files, createNewProjectFile(path, content)];
}

export async function syncBhojpuriStoryToProject(
  currentProject: StudioProject | null,
  story: BhojpuriStoryPlan,
  characters: BhojpuriCharacterSlot[]
): Promise<StudioProject> {
  const compactStory: BhojpuriStoryPlan = {
    ...story,
    thumbnailImageUrl: story.thumbnailImageUrl ? '[rendered-in-preview]' : undefined,
    scenes: story.scenes.map((s) => ({
      ...s,
      imageUrl: s.imageUrl ? '[rendered-in-preview]' : undefined,
    })),
  };

  const storyJson = JSON.stringify(compactStory, null, 2);
  const charsJson = JSON.stringify(
    characters.map((c) => ({ ...c, photoDataUrl: c.photoDataUrl ? '[stored-photo]' : null })),
    null,
    2
  );
  const flowTxt = formatGoogleFlowPrompt(story, characters);

  if (!currentProject) {
    return createProject({
      name: story.viralTitle.slice(0, 48),
      department: 'bhojpuri',
      files: [
        createNewProjectFile('bhojpuri-story.json', storyJson),
        createNewProjectFile('google-flow-prompt.txt', flowTxt),
        createNewProjectFile('characters.json', charsJson),
      ],
    });
  }

  let nextFiles = upsertProjectFile(currentProject.files, 'bhojpuri-story.json', storyJson);
  nextFiles = upsertProjectFile(nextFiles, 'google-flow-prompt.txt', flowTxt);
  nextFiles = upsertProjectFile(nextFiles, 'characters.json', charsJson);

  return saveProject({
    ...currentProject,
    files: nextFiles,
  });
}
