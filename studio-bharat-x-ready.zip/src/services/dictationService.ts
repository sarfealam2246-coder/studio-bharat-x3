import { DictationStatus, Language } from '../types/studio';
import {
  getMsSinceLiveMicRelease,
  isLiveSessionActive,
  stopLiveSession,
} from './geminiLiveService';

const ANDROID_MIC_LOCK_GUARD_MS = 160;
const PAUSE_REARM_DELAY_MS = 600;

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

interface SpeechRecognitionErrorEventLike {
  error: string;
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

export interface DictationOptions {
  language: Language;
  isHandsFreeActive: () => boolean;
  canListenNow: () => boolean;
  onInterimTranscript?: (text: string) => void;
  onFinalTranscript: (text: string) => void;
  onStatusChange?: (status: DictationStatus) => void;
}

let recognition: SpeechRecognitionLike | null = null;
let status: DictationStatus = 'idle';
let activeOptions: DictationOptions | null = null;
let rearmTimer: number | null = null;
let guardTimer: number | null = null;
let manuallyStopped = false;
let startSequenceId = 0;

function getSpeechRecognitionCtor(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const win = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return win.SpeechRecognition ?? win.webkitSpeechRecognition ?? null;
}

function updateStatus(next: DictationStatus): void {
  if (status === next) return;
  status = next;
  activeOptions?.onStatusChange?.(next);
}

function clearTimers(): void {
  if (rearmTimer !== null) {
    window.clearTimeout(rearmTimer);
    rearmTimer = null;
  }
  if (guardTimer !== null) {
    window.clearTimeout(guardTimer);
    guardTimer = null;
  }
}

function schedulePatientRearm(delayMs = PAUSE_REARM_DELAY_MS): void {
  clearTimers();
  const opts = activeOptions;
  if (!opts || manuallyStopped || !opts.isHandsFreeActive()) {
    updateStatus('idle');
    return;
  }
  updateStatus('rearming');
  rearmTimer = window.setTimeout(() => {
    rearmTimer = null;
    const latest = activeOptions;
    if (!latest || manuallyStopped || !latest.isHandsFreeActive()) {
      updateStatus('idle');
      return;
    }
    if (!latest.canListenNow()) {
      updateStatus('idle');
      return;
    }
    void startDictation(latest);
  }, delayMs);
}

function destroyRecognitionInstance(): void {
  if (!recognition) return;
  const current = recognition;
  recognition = null;
  current.onstart = null;
  current.onresult = null;
  current.onerror = null;
  current.onend = null;
  try {
    current.abort();
  } catch {
    try {
      current.stop();
    } catch {
      // Ignore already-stopped recognition errors.
    }
  }
}

export function isDictationSupported(): boolean {
  return getSpeechRecognitionCtor() !== null;
}

export function isDictationActive(): boolean {
  return status === 'listening' || status === 'rearming';
}

export function getDictationStatus(): DictationStatus {
  return status;
}

export function stopDictation(): void {
  manuallyStopped = true;
  startSequenceId += 1;
  clearTimers();
  destroyRecognitionInstance();
  updateStatus('idle');
}

export function pauseDictationTemporarily(): void {
  startSequenceId += 1;
  clearTimers();
  destroyRecognitionInstance();
  updateStatus('idle');
}

export async function startDictation(options: DictationOptions): Promise<boolean> {
  const Ctor = getSpeechRecognitionCtor();
  activeOptions = options;
  if (!Ctor) {
    updateStatus('unsupported');
    return false;
  }

  manuallyStopped = false;
  clearTimers();
  destroyRecognitionInstance();

  const mySeq = ++startSequenceId;

  // 160ms Android Mic-Lock Sequential Guard:
  // Always disconnect Gemini Live getUserMedia BEFORE starting SpeechRecognition.
  let needsGuardDelay = false;
  if (isLiveSessionActive()) {
    stopLiveSession();
    needsGuardDelay = true;
  } else if (getMsSinceLiveMicRelease() < ANDROID_MIC_LOCK_GUARD_MS) {
    needsGuardDelay = true;
  }

  if (needsGuardDelay) {
    const remainingGuard = Math.max(
      0,
      ANDROID_MIC_LOCK_GUARD_MS - Math.min(ANDROID_MIC_LOCK_GUARD_MS, getMsSinceLiveMicRelease())
    );
    const waitMs = remainingGuard > 0 ? remainingGuard : ANDROID_MIC_LOCK_GUARD_MS;
    await new Promise<void>((resolve) => {
      guardTimer = window.setTimeout(() => {
        guardTimer = null;
        resolve();
      }, waitMs);
    });
  }

  if (mySeq !== startSequenceId || manuallyStopped || !options.canListenNow()) {
    updateStatus('idle');
    return false;
  }

  const instance = new Ctor();
  instance.lang = options.language === 'hi' ? 'hi-IN' : 'en-US';
  instance.continuous = false;
  instance.interimResults = true;
  instance.maxAlternatives = 1;

  let fatalPermissionError = false;
  let deliveredFinal = false;

  instance.onstart = () => {
    if (recognition !== instance) return;
    updateStatus('listening');
  };

  instance.onresult = (event: SpeechRecognitionEventLike) => {
    if (recognition !== instance) return;
    let interim = '';
    let finalText = '';

    for (let i = event.resultIndex; i < event.results.length; i++) {
      const result = event.results[i];
      const text = result[0]?.transcript ?? '';
      if (result.isFinal) {
        finalText += text;
      } else {
        interim += text;
      }
    }

    if (interim.trim()) {
      options.onInterimTranscript?.(interim.trim());
    }

    if (finalText.trim()) {
      deliveredFinal = true;
      options.onInterimTranscript?.('');
      options.onFinalTranscript(finalText.trim());
    }
  };

  instance.onerror = (event: SpeechRecognitionErrorEventLike) => {
    if (recognition !== instance) return;
    const code = event.error;

    // Patient Pause / Gap Tolerance:
    // On 'no-speech' or 'aborted' (e.g. 2-3s user thinking pause), do NOT disable Hands-Free
    // and do NOT spam error messages; re-arm smoothly after 600ms.
    if (code === 'no-speech' || code === 'aborted') {
      if (options.isHandsFreeActive() && !manuallyStopped) {
        schedulePatientRearm(PAUSE_REARM_DELAY_MS);
      } else {
        updateStatus('idle');
      }
      return;
    }

    if (code === 'not-allowed' || code === 'service-not-allowed') {
      fatalPermissionError = true;
      updateStatus('idle');
      return;
    }

    // Transient network / audio-capture hiccup: re-arm gently if Hands-Free is ON
    if (options.isHandsFreeActive() && !manuallyStopped) {
      schedulePatientRearm(PAUSE_REARM_DELAY_MS);
    } else {
      updateStatus('idle');
    }
  };

  instance.onend = () => {
    if (recognition !== instance) return;
    recognition = null;
    options.onInterimTranscript?.('');

    if (manuallyStopped || fatalPermissionError) {
      updateStatus('idle');
      return;
    }

    // If a final transcript was just delivered, App.tsx will re-arm cleanly once VEDA finishes speaking.
    if (deliveredFinal) {
      updateStatus('idle');
      return;
    }

    if (options.isHandsFreeActive() && options.canListenNow()) {
      schedulePatientRearm(PAUSE_REARM_DELAY_MS);
    } else {
      updateStatus('idle');
    }
  };

  recognition = instance;
  try {
    instance.start();
    return true;
  } catch {
    recognition = null;
    if (options.isHandsFreeActive() && !manuallyStopped) {
      schedulePatientRearm(PAUSE_REARM_DELAY_MS);
    } else {
      updateStatus('idle');
    }
    return false;
  }
}
